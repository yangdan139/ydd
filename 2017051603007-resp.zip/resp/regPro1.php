<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3c.org/TR/1999/REC-html401-19991224/loose.dtd">
<HEAD>
<TITLE>注册协议</TITLE>
<META http-equiv=Content-Type content="text/html; charset=utf-8">
	<style>
		body{background-image: url("images/pic13.gif");}
	</style>
<LINK href="CSS/style.css" type=text/css rel=stylesheet>
<script src="JS/check.js" language="javascript">
</script>
</HEAD>
<BODY style="MARGIN-TOP: 0px; VERTICAL-ALIGN: top; PADDING-TOP: 0px; TEXT-ALIGN: center;background-color:paleturquoise; "> 
	
<div border="2" style=" width:757px; margin:0 auto; background-color:peachpuff;" >
  <TABLE width="757" cellPadding=0 cellSpacing=0 style="WIDTH: 755px; " align="center"> 
    <TBODY > 
      <TR> <TD style="VERTICAL-ALIGN: bottom; HEIGHT: 6px" colSpan=3 background="images/pic2.jpg">
      	<div width="100%"height="149"  border="0" cellpadding="0" cellspacing="0">
      		<p style="font-size:25px;text-align:center;">欢迎注册</p>
      	</div>
		  <br>
        <tr>
		<form name="form" method="post" action="checkuser1.php">
          <td height="20" valign="baseline">
            <table width="100%"  border="0" cellpadding="0" cellspacing="0">
              <tr>
                <td width="32%" height="20" align="center" valign="baseline">&nbsp; </td>
                <td width="67%" align="left" valign="baseline" style="text-indent:10px;">
				
				用户名:
                  <input  name="txt_user" size="10"><font style="color:red;">*yd</font>
密&nbsp;码:
<input  name="txt_pwd" id="txt_pwd" type="password" style="FONT-SIZE: 10px; WIDTH: 65px;" size="5"><font style="color:red;">*111</font>

<input style="FONT-SIZE: 9pt;"  type="submit" value="登录" name="sub_dl" onClick="return f_check(form)">
&nbsp; 
				<input type="reset" value="重置" style="font-size:9pt;">
				</td>
                <td width="1%" align="center" valign="baseline">&nbsp;</td>
              </tr>
            </table> 
			</td>
		  </form>
        </tr></TD> 
      </TR> 
      <TR> 
        <TD colSpan=3 valign="middle" style="BACKGROUND-IMAGE: url(' images/bg.jpg'); VERTICAL-ALIGN: middle; HEIGHT: 450px; TEXT-ALIGN: center;height:495px;">
        	<div align="center">
        	 <TABLE height="304" cellPadding=0 cellSpacing=0 style="WIDTH: 224px; text-align: center; "> 
            <TBODY align="center"> 
              <TR> 
                <TD height="29" 
            style="WIDTH: 368px; HEIGHT: 21px; TEXT-ALIGN: center"><STRONG><SPAN 
            style="COLOR: #993300">用户注册协议</SPAN></STRONG></TD> 
              </TR> 
              <TR> 
                <TD style="WIDTH: 368px; HEIGHT: 302px" rowSpan="2"> <TABLE 
            style="BORDER-RIGHT: black thin solid; BORDER-TOP: black thin solid; BORDER-LEFT: black thin solid; WIDTH: 369px; BORDER-BOTTOM: black thin solid" 
            align=center> 
                    <TBODY> 
                      <TR> 
                        <TD style="HEIGHT: 15px; TEXT-ALIGN: left" colSpan=4 
                  rowSpan=4>&nbsp;&nbsp;&nbsp;&nbsp;为维护网上公共秩序和社会稳定，请您自觉遵守以下条款：
                          <BR> 
                          一、不得利用本站危害国家安全、泄露国家秘密，不得侵犯国家社会集体的和公民的合法权益，不得利用本站制作、复制和传播下列信息： <BR> 
                          （一）煽动抗拒、破坏宪法和法律、行政法规实施的； <BR> 
                          （二）煽动颠覆国家政权，推翻社会主义制度的； <BR> 
                          （三）煽动分裂国家、破坏国家统一的； <BR> 
                          （四）煽动民族仇恨、民族歧视，破坏民族团结的； <BR> 
                          （五）捏造或者歪曲事实，散布谣言，扰乱社会秩序的； <BR> 
                          （六）宣扬封建迷信、淫秽、色情、赌博、暴力、凶杀、恐怖、教唆犯罪的； <BR> 
                          （七）公然侮辱他人或者捏造事实诽谤他人的，或者进行其他恶意攻击的； <BR> 
                          （八）损害国家机关信誉的； <BR> 
                          （九）其他违反宪法和法律行政法规的； <BR> 
                          （十）进行商业广告行为的。 <BR> 
                          二、互相尊重，对自己的言论和行为负责。</TD> 
                      </TR> 
                      <TR></TR> 
                      <TR></TR> 
                      <TR></TR> 
                      <TR> 
                        <TD style="HEIGHT: 8px; TEXT-ALIGN: center" colSpan=4><INPUT id="Button1" style="FONT-SIZE: 9pt" type="submit" value="同意" name="Button1" onClick="window.location.href='register1.php'"> 
&nbsp; 
                          <INPUT id=Button2 style="FONT-SIZE: 9pt" type="submit" value="不同意 " name="Button2" onClick="window.location.href='index1.php'"></TD> 
                      </TR> 
                    </TBODY> 
                  </TABLE></TD> 
              </TR> 
              <TR></TR> 
            </TBODY> 
          </TABLE>
          </div></TD> 
      </TR> 
    </TBODY>
     <table  width="757" border="0" align="center" cellpadding="0" cellspacing="0">
  <div align="center"> 版权所有  重庆师范大学计算机与信息科学学院   17计科杨丹 QQ:1390807583  </div>
  </table> 
  </TABLE> 
  </div>
</BODY>
</HTML>