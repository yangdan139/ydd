<?php session_start();
	include "Conn/conn.php";//包含连接数据库的文件 
	$id=$_SESSION["uid"];
//echo $id;
	?>
<html>
<head>
	
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link href="CSS/style.css" rel="stylesheet">
<title>我的关注</title>

<style type="text/css">
<!--
#banner{margin:0 auto;/*外边距为0，左右居中*/
		padding: 0;}
#container{position: relative;
		margin: 0 auto; /*整个网··页版面居中*/
		padding: 0;
		background-color: transparent;
		width: 757px;/*宽度为1000px*/
		text-align: right; /*左对齐*/
		border: 2px solid white;}
.style1 {color: #FF0000}
.demo{
	text-shadow: 0 0 5px #fff,0 0 15px #fff,0 0 25px #fff,0 0 20px #f0f,0 0 30px #f0f;} /*添加的文字效果*/
#banner p{text-align: center; /*左右居中*/
		padding:15px 0 0 0;
		font-size: 48px; /*字体大小*/
		color: #fff;
		font-weight: bold;
		background-image:url("images/first.jpg");} /*粗字体*/
#banner{margin:0px; /*外边距*/
		padding:0;
		margin: -50px 0 0 0;
		width: 757px; /*banner的宽度*/
			background:#e6cbfe ;
			}
			
			
	#links{font-size: 1em; /*字体大小，相对大小*/
		margin:-4px 0 0 0;
		padding:0; /*内边距*/
		position: relative;
		width:757px;}
#links ul{list-style-type:none;  /*去掉项目符号*/
		padding: 0;
		margin:0 auto;
			width: 1000px;}
			#links ul li a{text-align: center;
			/*background: url(img/pic5.jpg); /*背景图片*/
			width: 150px;
			height: 20px;
			vertical-align: middle; /*垂直居中*/
			display: inline-block; /*块显示*/
			float: left;
		  font-weight: bold; /*粗体字*/
			color: deepskyblue;
			background-color:burlywood;
			text-decoration: none; /*无装饰效果*/}
			#footer{clear: both; /*清除左右浮动*/
			font-size: 10px;
			font-weight: bold; /*粗体字*/
			width: 100%;
			padding: 3px 0px;
			text-align: center;/*文本居中*/
			margin: 0;
			background-color: #fff;} /*背景色：白色*/
			
					
body,html{
		background-color: lightcyan;
		background-image: url("images/pic13.gif");
		}
			
#input1{
				background: transparent;/*输入框背景透明*/
				border: none;
				color:#ffb400;
				font-size: 50px;
				font-weight: bold;
				font-family: 黑体;
				text-shadow: 0 0 5px #fff,0 0 15px #fff,0 0 25px #fff,0 0 20px #f0f,0 0 30px #f0f;
			}
-->
</style>
</head>


<script language="javascript">
/*function check(){
	if(myform.txt_title.value==""){
		alert("博客主题名称不允许为空！");myform.txt_title.focus();return false;
	}
	if(myform.file.value==""){
		alert("文章内容不允许为空！");myform.file.focus();return false;
	}
}*/
			function check2(){
				var oMy = document.getElementsByTagName("ul")[1];
				oMy.className = "myUL2";//追加css类
			}
			function check1(){
				var oP = document.getElementsByTagName("ul")[2];
				oP.className = "myUL1";
				//改变css类选择器
			}
				function check3(){
				var oMy = document.getElementsByTagName("ul")[3];
				oMy.className = "myUL3";//追加css类
			}
		</script>
<body >
<div class="container"align="center" style="border:2px solid white;">
	<table width="757">
		<div id="banner" style="border:1px solid peachpuff;">
			<p class="demo" >我的关注</p>
		</div></table>
		<div id="links" style="width:757px;">
	  	<ul >
	  		<li  ><a href="shouye.php" >首页</a></li>
	  		<li><a href="file.php">文章管理</a></li>
	  		<li><a href="myfans.php" >我的粉丝</a></li>
	  		<li><a href="browseuser.php" >个人信息</a></li>
	  		<li><a href="safe.php">退出登录</a></li>
	  	</ul>
	 </div>
	 <div style="border:2px solid tan;margin-top:20px; background-color:khaki; width:757px;height:495px;">
	 			<h1 align="center" style="font-size:20px;">我的关注</h1>
	 	<table width="700" style=" margin:20px;">
	 		<form name="form2" method="post">
	 			<tr width="700" style="font-size:12px;text-align:center;" align="center" bgcolor="burlywood">
	  				<td  style="border:1px solid peru;font-size:12px;text-align:center; " align="center">序号</td>
	  				<td style="border:1px solid peru;font-size:12px;text-align:center;" align="center">博客名</td>
	  				<td  style="border:1px solid peru;font-size:12px;text-align:center;" align="center">个人说明</td>
	  				<td   style="border:1px solid peru;font-size:12px;text-align:center;" align="center">取消关注</td>
	  				<td   style="border:1px solid peru;font-size:12px;text-align:center;" align="center">博客文章</td>
	  				<!--<td   style="border:1px solid peru;font-size:12px;text-align:center;" align="center">详细信息</td>-->
	  				
	  			</tr>
	 		<?php
                                       	$i=1;
                                       	
                                       	    $sql=mysql_query("select * from tb_bguser join tb_concern on tb_concern.au_id=tb_bguser.user_id where tb_concern.user_id='".$id."'");
                                       	    if (!$sql)
			    {
                    printf("Error: %s\n", mysql_error());
                    exit();
                }
                                       	    $row=mysql_fetch_array($sql);
                                       	    if(!$row)
                                       	    {
                                       	?>    	<tr align="center">
                                       	           <td>暂无关注！</td>
                                                </tr> 
                                       	<?php 
                                       	    }
                                       	    else{
                                       	    	do{
                                       	?>
                                       	          <tr width="700" style="border:1px solid peru;font-size:12px;text-align:center;" align="center">
                                       	            <td style="border:1px solid peru;font-size:12px;text-align:center;" align="center" width="25">
                                       	            	<a size="2"><?php echo $i."、";?> </a>
                                       	            </td >
                                       	            <td style="border:1px solid peru;font-size:12px;text-align:center;margin-left:10px;width:30px; height:15px;" >
                                       	            	<?php echo $row['u_name'];?></td>
                                       	            	
                                       	            <td style="border:1px solid peru;font-size:12px;text-align:center; width:200px;margin-left:10px;height:15px;"  >
                                       	            	
                                       	            		<?php echo $row['introduction']; ?>
                                       	            	</td>
                                       	            	<td style="border:1px solid peru;font-size:12px;text-align:center;margin-left:10px;width:30px; height:15px;" >
                                       	            	
                                       	            	
                                       	            	<a href="check_none.php?auid=<?php echo $row['au_id'];?>">取消关注</a>
                                       	            	
                                       	            </td>
                                       	            <td style="border:1px solid peru;font-size:12px;text-align:center;margin-left:10px;width:30px; height:15px;" >
                                       	            	<a href="aufiles.php?auid=<?php echo $row['au_id'];?> ">查看文章</a>
                                       	            </td>
                                       	            <!--<td   style="border:1px solid peru;font-size:12px;text-align:center;" align="center"><a href="browseuser.php?aiid=<?php echo $row['au_id'];?>"></a> 
                                       	            	
                                       	            </td>-->
                                       	            </tr>
                                       	            <?php
                                       	            	$i++;
                                       	            }while($row=mysql_fetch_array($sql));
                                       	            }
                                       	            ?>
                                       	            </form>
                                       	            </table>

	 </div>
                                       	            	<div class="footer" style="float:bottom;"> 版权所有  重庆师范大学计算机与信息科学学院   17计科杨丹 QQ:1390807583  </div>

</div> 
</body>
</html>
