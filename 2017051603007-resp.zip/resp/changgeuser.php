<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8" />
		<title></title>
	</head>
	<body>
<?php
	header ( "Content-type: text/html; charset=utf-8" ); //设置文件编码格式
session_start();
include "Conn/conn.php";//包含连接数据库的文件
$name=$_POST["u_name"];
//echo $name;
$QQ=$_POST["u_QQ"];
//echo $QQ;
$email=$_POST["u_email"];
//echo $email;
$birthday=$_POST["u_birthday"];
//echo $birthday;
$id=$_SESSION["uid"];
//echo $id;
$introduction=$_POST["introduction"];
//echo $introduction;
$sql=mysql_query("update tb_bguser set u_name='".$name."',u_QQ='".$QQ."',u_email='".$email."',u_birthday='".$birthday."',introduction='".$introduction."' where user_id='".$id."' ");//在用户表中修改用户信息

//$result=mysql_fetch_array($sql);
if (!$sql)
			    {
                    printf("Error: %s\n", mysql_error());
                    exit();
                }
if($sql!=""){
//$_SESSION["username"]=$name;
?>
<script language="javascript">
	alert("修改成功");history.back();//如果有，则登录成功
</script>
<?php
}else{
?>
<script language="javascript">
	alert("修改失败!");history.back();
</script>
<?php
}
?>
</body>
</html>
