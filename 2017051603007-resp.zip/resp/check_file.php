<?php
header ( "Content-type: text/html; charset=utf-8" ); //设置文件编码格式
session_start();
include "Conn/conn.php";//包含连接数据库的文件
//$classid=$_POST["classid"];
$classname=$_POST["class"];
$sql=mysql_query("select * from tb_class where classname='".

$classname."'");
$row=mysql_fetch_array($sql);
$classid=$row["classId"];
//echo $classid;
mysql_free_result($sql);
$title=$_POST["txt_title"];//获取文章主题
//echo $title;
//@$a_id=$_SESSION["a_id"];//获取文章ID
$user_id=$_POST["uiid"];
//echo $user_id;
$content=$_POST["file"];//获取文章内容
//echo $content;
$time=date("Y-m-d H:i:s"); //获取文章发表时间
//echo $time;
$sqle=mysql_query("insert into tb_articles (user_id,title,a_content,time,classId) values ('$user_id','$title','$content','$time','$classid')");//将发表的文章的所有内容按相应位置插入到文章表中
if (!$sqle)
			    {
                    printf("Error: %s\n", mysql_error());
                    exit();
                }
if($sqle){
	echo "<script>alert('恭喜您，你的文章发表成功!!!');history.back();</script>";//window.location.href='myfiles.php';
}
else{
	echo "<script>alert('对不起，添加操作失败!!!');history.back();</script>";//window.location.href='file.php';
}

?>

