<?php 
	session_start();
	include "Conn/conn.php";
	?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link href="CSS/style.css"  rel="stylesheet">
<title>所有文章</title>
<meta name="viewport" content="width=device-width,initial=scale=1.0"/>
		<link rel="stylesheet" href="../bootstrap-v2.3.2/css/bootstrap.css" />
		<link rel="stylesheet" href="../bootstrap-v2.3.2/css/bootstrap-responsive.css" />
		<script src="../bootstrap-v2.3.2/js/jquery.js"></script>
		<script src="../bootstrap-v2.3.2/js/bootstrap-dropdown.js"></script>
			<script src="../bootstrap-v2.3.2/js/bootstrap-collapse.js"></script>
		<style type="text/css">
				body{margin:10px;
				background-color:palegoldenrod;
				background-image:url('images/timg7.gif');
				}
			#footer{clear: both; /*清除左右浮动*/
			font-size: 10px;
			font-weight: bold; /*粗体字*/
			width: 100%;
			padding: 3px 0px;
			text-align: center;/*文本居中*/
			margin: 0;
			background-color: #fff;} /*背景色：白色*/
			</style>
</head>
<script src="JS/check.js"  language="javascript"></script>
<body style="margin-top: 0px; vertical-align: top; padding-top: 0px; text-align: center;background-color:palegoldenrod; "> 
	<?php
       if(empty($_SESSION['uid']))
        {
           echo "<script>alert('您还没有登录,请先登录!');history.back();</script>";
           exit;
        }
?>
			<div style="margin:auto; border:2px solid white;" align="center" class="container">
		<div  style="height:149px;background-image:url('images/footer.jpg');">
			<h2 style="font-size:25px;text-align:center;padding-top:62px;">所有文章</h2></div>
		<div class="navbar" style="text-align:center;margin:auto;"align="center">
			<div class="navbar-inner">
				<a  class="btn btn-navbar" data-toggle="collapse" data-target=".navbar-responsive-collapse" >
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</a>
				<a href="index1.php" class="brand">博客系统</a>
				<ul class="nav nav-collapse collapse navbar-responsive-collapse">
					<li ><a href="shouye1.php"style="background-color:lightgoldenrodyellow;border-radius:8px;"><i class="icon-home"></i>首页</a></li>
					<li class="divider-vertical"></li>
							<li style="background-color:bisque; border-radius:4px;"><a href="file1.php">发表文章</a></li>
							<li class="divider-vertical"></li>
							<li style="background-color:bisque; border-radius:4px;" class="active"><a href="file_more1.php">所有文章</a></li>
							<li class="divider-vertical"></li>
							<li style="background-color:bisque; border-radius:4px;"><a href="myfiles1.php">我的文章</a></li>
							<li class="divider-vertical"></li>
							
					<li class="dropdown">
						<a href="#" data-toggle="dropdown" style="background-color:lightgoldenrodyellow;width:100px;margin-left:20px;border-radius:8px;">个人中心<b class="caret"></b></a>
						<ul class="dropdown-menu">
							<li style="background-color:bisque; border-radius:4px;"><a href="browseuser1.php">个人信息</a></li>
							<li class="divider"></li>
							<li style="background-color:bisque; border-radius:4px;"><a href="myfans1.php">我的粉丝</a></li>
							<li class="divider"></li>
							<li style="background-color:bisque; border-radius:4px;"><a href="concern1.php">我的关注</a></li>
						</ul>
					</li>
					<li class="divider-vertical"></li>
					<li>
						<a href="safe2.php" style="background-color:lightgoldenrodyellow;width:100px;border-radius:8px;"><i class="icon-off"></i>退出</a></li>
				</ul>
			</div>
		</div>
      <div >
      	<div class="span3" style="border:color:transparent; background-color:transparent;float:left;"></div>
	  	<div style="height:495px;background-image:url('images/bg.jpg');" align="center" class="span7">
	  		<h2 align="center" style="text-align:center;">
	  			所有文章
	  		</h2>
	  		<table align="center" cellpadding="2" bgcolor="palegoldenrod" class="table-condensed">
	  			<thead  style="font-size:12px;text-align:center;" align="center" bgcolor="burlywood">
	  				<th  style="border:1px solid peru;font-size:12px;text-align:center; " align="center">编号</th>
	  				<th style="border:1px solid peru;font-size:12px;text-align:center;" align="center">文章主题</th>
	  				<th style="border:1px solid peru;font-size:12px;text-align:center;" align="center">文章作者</th>
	  				<th  style="border:1px solid peru;font-size:12px;text-align:center;" align="center">发表时间</th>
	  				<th   style="border:1px solid peru;font-size:12px;text-align:center;" align="center">关注</th>
	  			</thead>
	  			<tbody>
	  			<?php
                                       	$i=1;
                                       	    $sql=mysql_query("select  *from tb_articles,tb_bguser where tb_articles.user_id=tb_bguser.user_id");
                                       	   
                                       	    if (!$sql)
			    {
                    printf("Error: %s\n", mysql_error());
                    exit();
                }
                                       	    $row=mysql_fetch_array($sql);
                                       	    // $id=$row['au_id'];
                                       	  //  $sql1=mysql_query("select bgname form tb_author where au_id=$id");
                                       	   // $row1=mysql_fetch_array($sql1);
                                       	    if($row=="")
                                       	    {
                                       	?>    	<tr align="center">
                                       	           <td>暂无文章！！！</td>
                                                </tr> 
                                       	<?php 
                                       	    }
                                       	    else{
                                       	    	do{
                                       	?>
                                       	          <tr style="border:1px solid peru;font-size:12px;text-align:center;" align="center">
                                       	            <td style="border:1px solid peru;font-size:12px;text-align:center;" align="center" width="25">
                                       	            	<a href="article_1.php?a_id=<?php echo $row['a_id'];?>"size="2"><?php echo $i."、";?> </a>
                                       	            </td >
                                       	            <td style="border:1px solid peru;font-size:12px;text-align:center;" align="center">
                                       	            	<a href="article_1.php?a_id=<?php echo $row['a_id'];?>"><?php echo $row['title'];?></a></td>
                                       	            	<td style="border:1px solid peru;font-size:12px;text-align:center;" align="center">
                                     	            	<a href="article_1.php?a_id=<?php echo $row['a_id'];?>"><?php echo $row['u_name'];?></a></td>
                                       	            	<td style="border:1px solid peru;font-size:12px;text-align:center;" align="center">
                                       	            	<a ><?php echo $row['time'];?></a></td>
                                       	            
                                       	            <td style="border:1px solid peru;font-size:12px;text-align:center;" align="center">
                                       	            	<a href="check_add.php?fanid=<?php echo $row['user_id'];?>">关注</a></td>
                                       	            
                                                  </tr> <br><br>
                                       	<?php
                                       		$i++;    		
                                       	}while($row=mysql_fetch_array($sql));
                                       	    }
                                       	?> 
                                       	</tbody>
	  		</table>
	  	</div>
	</div>
	<div class="span3" style="border:color:transparent; background-color:transparent;float:right;"></div>
  <div align="center" id="footer"> 版权所有  重庆师范大学计算机与信息科学学院   17计科杨丹 QQ:1390807583  </div>
</div> 
</body>
</html>