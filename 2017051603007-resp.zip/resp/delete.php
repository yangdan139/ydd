
<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8" />
		<title></title>
	</head>
	<body>
		<?php    
			session_start();
    header ( "Content-type: text/html; charset=utf-8" ); 
	include "Conn/conn.php";//包含链接数据库的文件
	$uid=$_SESSION['uid'];
	//echo $uid;
	$id=$_GET['aid'];
	//echo $id;
	$sql=mysql_query("select * from tb_articles join tb_bguser on tb_articles.user_id=tb_bguser.user_id where tb_articles.a_id='".$id."'");
	$row=mysql_fetch_array($sql);
	if (!$sql)
			    {
                    printf("Error: %s\n", mysql_error());
                    exit();
            }
            
	$name=$row['u_name'];
	//echo $name;
	$title=$row['title'];
	//echo $title;
	$content=$row['a_content'];
	//echo $content;
	$time=date("Y-m-d H:i:s"); //获取文章删除时间
	//echo $time;
	
	$sql1=mysql_query("insert into tb_delete (ad_id,name,d_title,d_content,d_time) values ('$uid','$name','$title','$content','$time')");
	if (!$sql1)
			    {
                    printf("Error: %s\n", mysql_error());
                    exit();
            }
            $sql2=mysql_query("delete from tb_comment where a_id='".$id."'");
	$sql=mysql_query("delete from tb_articles where a_id='".$id."'");
    if (!$sql)
			    {
                    printf("Error: %s\n", mysql_error());
                    exit();
                }
	if($sql){
		echo "<script>alert('删除成功!');history.back();</script>";
	}
	else{	
		echo "<script>alert('删除操作失败！');history.back();</script>";
	}
	?>
	</body>
</html>
