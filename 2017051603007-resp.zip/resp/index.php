<?php 
session_start();
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>博客系统</title>
<link href="CSS/style.css" rel="stylesheet"/>
<style type="text/css">
#banner{margin:0 auto;/*外边距为0，左右居中*/
			padding: 0;}
			#container{position: relative;
			margin: 0 auto; /*整个网··页版面居中*/
			padding: 0;
			background-color: transparent;
			width: 757px;/*宽度为1000px*/
			text-align: left; /*左对齐*/
			border: 2px solid white;}
			.demo{text-shadow: 0 0 5px #fff,0 0 15px #fff,0 0 25px #fff,0 0 20px #f0f,0 0 30px #f0f;} /*添加的文字效果*/
			#banner p{text-align: center; /*左右居中*/
			padding:15px 0 0 0;
			font-size: 48px; /*字体大小*/
			color: #fff;
			font-weight: bold;} /*粗字体*/
			#banner{margin:0px; /*外边距*/
			padding:0;
			margin: -50px 0 0 0;
			width: 757px; /*banner的宽度*/
			height:
			background:#e6cbfe ;}
			#links{font-size: 1em; /*字体大小，相对大小*/
			margin:-4px 0 0 0;
			padding:0; /*内边距*/
			position: relative;}
			#links ul{list-style-type:none;  /*去掉项目符号*/
			padding: 0;
			margin:0 auto;
			width: 1000px;}
			#leftcontent{
				background-image:url("images/left.jpg");
			}
			
			#links ul li a{text-align: center;
			/*background: url(img/pic5.jpg); /*背景图片*/
			width: 250px;
			height: 20px;
			vertical-align: middle; /*垂直居中*/
			display: inline-block; /*块显示*/
			float: left;
		  font-weight: bold; /*粗体字*/
			color: deepskyblue;
			background-color:burlywood;
			text-decoration: none; /*无装饰效果*/}
			#footer{clear: both; /*清除左右浮动*/
			font-size: 10px;
			font-weight: bold; /*粗体字*/
			width: 100%;
			padding: 3px 0px;
			text-align: center;/*文本居中*/
			margin: 0;
			background-color: #fff;} /*背景色：白色*/
			
		body,html{
				background-color: lightcyan;
				background-image: url("images/timg8.gif");
			}
			input{
				background: transparent;/*输入框背景透明*/
				border: none;
				color:#ffb400;
				font-size: 50px;
				font-weight: bold;
				font-family: 黑体;
				text-shadow: 0 0 5px #fff,0 0 15px #fff,0 0 25px #fff,0 0 20px #f0f,0 0 30px #f0f;
			}
			#input{
				background-color:pink;
				border:1px solid peachpuff;
				font-size:10px;
				margin-top:20px;
				font-family:黑体;
			}
</style></script>
<script type="text/javascript">
			var msg=" Welcome to blog web";
			var interval = 400;
			var seq=0;
			function LenScroll(){
				document.nextForm.lenText.value = msg.substring(seq,msg.length) + "  "+msg;
				seq++;
				if(seq>msg.length)
				seq=0;
				window.setTimeout("LenScroll();",interval);
			}
			function check2(){
				var oMy = document.getElementsByTagName("ul")[1];
				oMy.className = "myUL2";//追加css类
			}
			function check1(){
				var oP = document.getElementsByTagName("ul")[2];
				oP.className = "myUL1";
				//改变css类选择器
			}
				function check3(){
				var oMy = document.getElementsByTagName("ul")[3];
				oMy.className = "myUL3";//追加css类
			}
			function check_class(Form){
				if(Form.search.value==""){
					alert ("请输入文章分类");
					Form.search.focus();
					return false;
				}
			}
		</script>
	</head>

<body onload="LenScroll()">
	<div id="container">
		<table width="757">
		<div id="banner" >
			<form name="nextForm">
			<p class="demo" ><input type="text" name="lenText"/></p></form></div></table>
		<div id="links" style="width:757px;">
	  	<ul onclick="check2()"style="width:757px; height:20px;" >
	  		<li><a href="denglu.php">登录</a></li>
	  		<li><a href="RegPro.php">注册</a></li>
	  		<li><a href="file.php" >文章管理</a></li>
	  	</ul>
	  </div>
	  <div id="leftcontent" style="width:236px; float:left; height:500px; margin-left:0px;margin-top:0px; "background="images/left.jpg">
	  	<table>
	  		<tr ><table width="100%" height="100%"  border="0" cellpadding="0" cellspacing="0">
		  <tr>
			<td height="155" align="center" valign="top">
				<?php include "cale.php"; ?>	</td>
		  </tr>
		  <tr>
			<td height="125" align="center" valign="top"><br>
	
			  <table width="200"  border="0" cellspacing="0" cellpadding="0">
				<tr>
				  <td><table width="201"  border="0" cellspacing="0" cellpadding="0" valign="top" style="margin-top:5px;">
					 <?php
		    	include "Conn/conn.php";
				$sql=mysql_query("select a_id,title from tb_articles order by time desc limit 5");//连接文章表，显示文章主题，每页显示5行
				if (!$sql)
			    {
                    printf("Error: %s\n", mysql_error());
                    exit();
                }
				$i=1;
				$info=mysql_fetch_array($sql);
				if(!$info){
					echo "暂时没有文章!!!";
				}
				else{
					do{
			?>
						<tr>
					  <td width="201" align="left" valign="top">
					  
					        <a href="article2.php?a_id=<?php echo $info['a_id'];?>"><?php echo $i."、".$info["title"];?> </a>
					       	  
					       	
					  </td>
					</tr>
			<?php
				$i++;
				}while($info=mysql_fetch_array($sql));
				}
			
			?>	
					<tr>
					  <td height="10" align="right"><a href="file_more.php"><img src=" images/more.gif" width="27" height="9" border="0">&nbsp;&nbsp;&nbsp;</a></td>
					</tr>
				  </table></td>
				</tr>
			</table></td></tr>
		  <tr>
			<td height="201" align="center" valign="top">          <br>
			  <table width="145"  border="0" cellspacing="0" cellpadding="0">
			  <tr>
				<td><table width="201"  border="0" cellspacing="0" cellpadding="0" valign="top" style="margin-top:5px;">
					
					<tr>
					  <td width="9" rowspan="2"  align="center">&nbsp;                                        </td>
					  <td width="147"  align="center"><img src="images/pic1.png"  width="120" height="80" border="0" style="border-radius:20px;">                                                          </td>
					  <td width="10" rowspan="2"  align="center">&nbsp;</td>
					</tr>
					<tr>
					  <td  align="center">图片名称：花</td>
					</tr>
					<tr>
					  <td width="9" rowspan="2"  align="center">&nbsp;                                        </td>
					  <td width="147"  align="center"><img src="images/pic2.png"  width="120" height="80" border="0">                                                          </td>
					  <td width="10" rowspan="2"  align="center">&nbsp;</td>
					</tr>
					<tr>
					  <td  align="center">图片名称：心</td>
					</tr>
			  		
				</table></td>
			  </tr>
			</table>        </td>
		  </tr>
		</table></tr>
	  	</table>
	  	
	  	
	  </div>
	  	<div style="border-radius:20px 30px;width:515px;float:right; padding-top:0px;margin-top:0px; background-color:lemonchiffon;height:495px;" >
	  				<td width="515" height="501" align="center" background="images/bg.jpg">
		<table width="100%" height="98%"  border="0" cellpadding="0" cellspacing="0">
      <tr>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td height="372" align="center"><table style="WIDTH: 252px" cellspacing=0 cellpadding=0>
        	<div  style="border:1px solid rosybrown;width: 372px; height: 280px; border-radius:4px;">
              
                <span style=" font-size:18px; text-align:center;">欢迎来到博客网！</span><br>
                	<p>
                		&nbsp;&nbsp;博客，仅音译，英文名为Blogger,为Web Log的混成词。它的正式名称为网络日记；又音译为部落格或部落阁等，是使用特定的软件，在网络上出版、发表和张贴个人文章的人，或者是一种通常由个人管理、不定期张贴新的文章的网站。博客上的文章通常以网员形式出现，并根据张贴时间，以倒序排列。博客是继MSN.BBS.ICQ之后出现的第4种网络交流方式，现已受到大家的欢迎，是网络时代的个人“读者文摘”，是以超级链接为武器的网络日记，它代表着新的生活、工作和学习方式。许多博客专注在特定的课题上提供评论或新闻，其他则被作为比较个人的日记。一个典型的博客结合了文字、图像、其他博客或网站的链接及其它与主题相关的媒体，能够让读者以互动的方式留下意见，是许多博客的重要要素。大部分的博客内容以文字为主，仍有一些博客专注在艺术、摄影、视频、音乐、播客等各种主题。博客是社会媒体网络的一部分。比较著名的有新浪、网易等博客。
                	</p>
               
			  
              </div>
            <tr></tr>
          
        </table></td>
      </tr>
      <tr>
        <td height="66">&nbsp;</td>
      </tr>
    </table>
	</td>
	  	</div>
	  	<div id="footer">
	    版权所有  重庆师范大学计算机与信息科学学院   17计科杨丹 QQ:1390807583 
	  </div>
	</div>
</body>
</html>
