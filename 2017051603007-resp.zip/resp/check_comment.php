<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title></title>
	</head>
	<body>
<?php
	session_start();
	include("conn.php");
	    $uid=$_POST["uiid"];
	    $aid=$_POST["aiid"];
	    $content=$_POST["addcon"];
	    $createtime=date("Y-m-d H:i:s");
	if(!isset($_SESSION["uid"]))
	{
		
		echo "<script language='javascript'>alert('你还没有登录哦');history.back();</script>";
		
	}else{
		
	    $sql=mysql_query("insert into tb_comment (a_id,c_content,c_date,user_id) values('$aid','$content','$createtime','$uid')");
	    if (!$sql)
			    {
                    printf("Error: %s\n", mysql_error());
                    exit();
                }
            if($sql)
            {
    	        echo "<script> alert('发布成功！！！');history.back();</script>";
            }
            else{
    	        echo "<script> alert('发布失败！！！');history.back();</script>";
            }
        mysql_close($conn);	
	}
?>
</body>
</html>
