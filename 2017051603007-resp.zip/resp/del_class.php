<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title></title>
	</head>
	<body>
		<?php 
			session_start();
			include "Conn/conn.php";//包含链接数据库的文件
	$uid=$_SESSION['uid'];
	//echo $uid;
	$classid=$_GET['cid'];
	//echo $classid;
	
	$sql=mysql_query("delete from tb_class where classId='".$classid."'");
	if (!$sql)
			    {
                    printf("Error: %s\n", mysql_error());
                    exit();
            }
            if($sql){
		echo "<script>alert('删除成功!');history.back();</script>";
	}
	else{	
		echo "<script>alert('删除操作失败！');history.back();</script>";
	}
	?>
	</body>
</html>
