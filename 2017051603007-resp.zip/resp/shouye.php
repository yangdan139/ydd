<?php 
session_start();
$id=$_SESSION['uid'];
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>博客系统</title>
<link href="CSS/style.css" rel="stylesheet"/>
<style type="text/css">
#banner{margin:0 auto;/*外边距为0，左右居中*/
			padding: 0;}
			#container{position: relative;
			margin: 0 auto; /*整个网··页版面居中*/
			padding: 0;
			background-color: transparent;
			width: 757px;/*宽度为1000px*/
			text-align: left; /*左对齐*/
			border: 2px solid white;}
			.demo{text-shadow: 0 0 5px #fff,0 0 15px #fff,0 0 25px #fff,0 0 20px #f0f,0 0 30px #f0f;} /*添加的文字效果*/
			#banner p{text-align: center; /*左右居中*/
			padding:15px 0 0 0;
			font-size: 48px; /*字体大小*/
			color: #fff;
			font-weight: bold;} /*粗字体*/
			#banner{margin:0px; /*外边距*/
			padding:0;
			margin: -50px 0 0 0;
			width: 757px; /*banner的宽度*/
			height:
			background:#e6cbfe ;}
			#links{font-size: 1em; /*字体大小，相对大小*/
			margin:-4px 0 0 0;
			padding:0; /*内边距*/
			position: relative;}
			#links ul{list-style-type:none;  /*去掉项目符号*/
			padding: 0;
			margin:0 auto;
			width: 1000px;}
			#leftcontent{
				background-image:url("images/left.jpg");
			}
			
			#links ul li a{text-align: center;
			/*background: url(img/pic5.jpg); /*背景图片*/
			width: 180px;
			height: 20px;
			vertical-align: middle; /*垂直居中*/
			display: inline-block; /*块显示*/
			float: left;
		  font-weight: bold; /*粗体字*/
			color: deepskyblue;
			background-color:burlywood;
			text-decoration: none; /*无装饰效果*/}
			#footer{clear: both; /*清除左右浮动*/
			font-size: 10px;
			font-weight: bold; /*粗体字*/
			width: 100%;
			padding: 3px 0px;
			text-align: center;/*文本居中*/
			margin: 0;
			background-color: #fff;} /*背景色：白色*/
			
		body,html{
				background-color: lightcyan;
				background-image: url("images/pic13.gif");
			}
			input{
				background: transparent;/*输入框背景透明*/
				border: none;
				color:#ffb400;
				font-size: 50px;
				font-weight: bold;
				font-family: 黑体;
				text-shadow: 0 0 5px #fff,0 0 15px #fff,0 0 25px #fff,0 0 20px #f0f,0 0 30px #f0f;
			}
</style></script>
<script type="text/javascript">
			var msg=" Welcome to blog web";
			var interval = 400;
			var seq=0;
			function LenScroll(){
				document.nextForm.lenText.value = msg.substring(seq,msg.length) + "  "+msg;
				seq++;
				if(seq>msg.length)
				seq=0;
				window.setTimeout("LenScroll();",interval);
			}
			function check2(){
				var oMy = document.getElementsByTagName("ul")[1];
				oMy.className = "myUL2";//追加css类
			}
			function check1(){
				var oP = document.getElementsByTagName("ul")[2];
				oP.className = "myUL1";
				//改变css类选择器
			}
				function check3(){
				var oMy = document.getElementsByTagName("ul")[3];
				oMy.className = "myUL3";//追加css类
			}
			function check_class(Form){
				if(Form.search.value==""){
					alert ("请输入文章分类");
					Form.search.focus();
					return false;
				}
			}
		</script>
	</head>

<body onload="LenScroll()">
	<div id="container">
		<table width="757">
		<div id="banner" >
			<form name="nextForm">
			<p class="demo" ><input type="text" name="lenText"/></p></form></div></table>
		<div id="links">
	  	<ul onclick="check2()" class="myUL1">
	  		<li><a href="file_more.php">所有文章</a></li>
	  		<li  ><a href="file.php" >发表文章</a></li>
	  		<li><a href="myfans.php" >我的粉丝</a></li>
	  		<li><a href="safe.php">退出登录</a></li>
	  	</ul>
	  </div>
	  <div id="leftcontent" style="width:236px; float:left; height:500px;"background="images/left.jpg">
	  	<table>
	  		<tr ><table width="100%" height="100%"  border="0" cellpadding="0" cellspacing="0">
		  <tr>
			<td height="155" align="center" valign="top">
				<?php include "cale.php"; ?>	</td>
		  </tr>
		  <tr>
			<td height="125" align="center" valign="top"><br>
	
			  <table width="200"  border="0" cellspacing="0" cellpadding="0">
				<tr>
				  <td><table width="201"  border="0" cellspacing="0" cellpadding="0" valign="top" style="margin-top:5px;">
					 <?php
		    	include "Conn/conn.php";
				$sql=mysql_query("select a_id,title from tb_articles order by time desc limit 5");//连接文章表，显示文章主题，每页显示5行
				if (!$sql)
			    {
                    printf("Error: %s\n", mysql_error());
                    exit();
                }
				$i=1;
				$info=mysql_fetch_array($sql);
				if(!$info){
					echo "暂时没有文章!!!";
				}
				else{
					do{
			?>
						<tr>
					  <td width="201" align="left" valign="top">
					  
					        <a href="article.php?a_id=<?php echo $info['a_id'];?>"><?php echo $i."、".$info["title"];?> </a>
					       	  
					       	
					  </td>
					</tr>
			<?php
				$i++;
				}while($info=mysql_fetch_array($sql));
				}
			
			?>	
					<tr>
					  <td height="10" align="right"><a href="file_more.php"><img src=" images/more.gif" width="27" height="9" border="0">&nbsp;&nbsp;&nbsp;</a></td>
					</tr>
				  </table></td>
				</tr>
			</table></td></tr>
		  <tr>
			<td height="201" align="center" valign="top">          <br>
			  <table width="145"  border="0" cellspacing="0" cellpadding="0">
			  <tr>
				<td><table width="201"  border="0" cellspacing="0" cellpadding="0" valign="top" style="margin-top:5px;">
					
					<tr>
					  <td width="9" rowspan="2"  align="center">&nbsp;                                        </td>
					  <td width="147"  align="center"><img src="images/pic1.png"  width="120" height="80" border="0" style="border-radius:20px;">                                                          </td>
					  <td width="10" rowspan="2"  align="center">&nbsp;</td>
					</tr>
					<tr>
					  <td  align="center">图片名称：花</td>
					</tr>
					<tr>
					  <td width="9" rowspan="2"  align="center">&nbsp;                                        </td>
					  <td width="147"  align="center"><img src="images/pic2.png"  width="120" height="80" border="0">                                                          </td>
					  <td width="10" rowspan="2"  align="center">&nbsp;</td>
					</tr>
					<tr>
					  <td  align="center">图片名称：心</td>
					</tr>
			  		
				</table></td>
			  </tr>
			</table>        </td>
		  </tr>
		</table></tr>
	  	</table>
	  	
	  	
	  </div>
	  	<div style="border-radius:20px 30px;width:521px;float:right; padding-top:0px;margin-top:0px; background-color:lemonchiffon;height:495px;" >
	  				<h1 style="font-size:15px;text-align:center;font-weight:blod;">分类搜索文章</h1>
	  		<div style="margin-top:50px;width:300px;border-radius:20px;">
	  				<table style="background-color:burlywood; margin-left:50px;margin-top:10px; height:50px;" align="center">
	  					
	  			<form action="article3.php"style="background-color:ref;height:500px;"height="200" name="Form" id="Form" method="post">
	  					<tr width="200">
	  				<td align="center" >
	  					<input type="text" size="20" style="font-size:14px; background-color:azure;margin-left:20px;" name="search1" id="search1"/>
	  					<input type="submit" value="搜索" onclick="return check_class();" style="font-size:14px; border:1px solid brown;font-weight:bolod;font-family: '微软雅黑';" />
	  				</td>
	  				
	  			</tr></form>
	  			<form>
	  			<tr>
	  					<?php
	  						$i=1;
	  						$sql=mysql_query("select* from  tb_class");
                                       	   
                                       	    if (!$sql)
			    {
                    printf("Error: %s\n", mysql_error());
                    exit();
                }
                                       	    $row=mysql_fetch_array($sql);
                                       	    // $id=$row['au_id'];
                                       	  //  $sql1=mysql_query("select bgname form tb_author where au_id=$id");
                                       	   // $row1=mysql_fetch_array($sql1);
                                       	    if($row=="")
                                       	    {
                                       	?>    	<tr align="center" style="margin-top:20px;">
                                       	           <td>暂无文章分类！！！</td>
                                                </tr> 
                                       	<?php 
                                       	    }
                                       	    else{
                                       	    	do{
                                       	?><tr>
                                       		<td>
                                       			<a href="article4.php?classid=<?php echo $row['classId'];?>"><?php echo $row['classname'];?></a>
                                       		</td>
                                       	</tr>
                                       	<?php
                                       		$i++;    		
                                       	}while($row=mysql_fetch_array($sql));
                                       	    }
                                       	?> 
                                       	
                                       	</tr>
                                       	</form>
	  			
	  			
	  			</table>
	  			</div>
	  	</div>
	  	<div id="footer">
	    版权所有  重庆师范大学计算机与信息科学学院   17计科杨丹 QQ:1390807583  2018.6.30
	  </div>
	</div>
</body>
</html>

