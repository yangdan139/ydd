<meta charset="utf-8">
	<?php
		session_start();
		include("Conn/conn.php");
	$title=$_POST["txt_title"];
	//echo $title;
	$content=$_POST["txt_content"];
	//echo $content;
	$uid=$_SESSION['uid'];
	//echo $uid;
	$cid=$_POST["id"];
	//echo $cid;
	$time=date("Y-m-d H:i:s"); //获取文章发表时间
	//echo $time;
	$sql=mysql_query("update tb_articles set title='".$title."',a_content='".$content."',time='".$time."' where a_id='".$cid."' and user_id='".$uid."'");
	if($sql){
		echo "<script>alert('文章修改成功!');</script>";
		echo "<script>history.back();</script>";
		}
		else{
			echo "<script>alert('修改失败!');history.back();</script>";
		}
		mysql_close($conn);
		?>

