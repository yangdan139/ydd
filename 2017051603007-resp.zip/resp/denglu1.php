<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>博客系统</title>
		<meta name="viewport" content="width=device-width,initial=scale=1.0"/>
		<link rel="stylesheet" href="../bootstrap-v2.3.2/css/bootstrap.css" />
		<link rel="stylesheet" href="../bootstrap-v2.3.2/css/bootstrap-responsive.css" />
		<script src="../bootstrap-v2.3.2/js/jquery.js"></script>
		<script src="../bootstrap-v2.3.2/js/bootstrap-dropdown.js"></script>
		<style type="text/css">
				body{margin:10px;
				background-color:papayawhip;
				}
			#footer{clear: both; /*清除左右浮动*/
			font-size: 10px;
			font-weight: bold; /*粗体字*/
			width: 100%;
			padding: 3px 0px;
			text-align: center;/*文本居中*/
			margin: 0;
			background-color: #fff;} /*背景色：白色*/
			</style>
</head>
	<script src="JS/check.js" language="javascript">
</script>
<body >
<div style="width:757px;margin:auto; border:2px solid white; height:664px; background-color:blanchedalmond;" align="center">
		<div  style="width:757px; height:149px;background-image:url('images/pic2.jpg');">
			<p style="font-size:25px;text-align:center;padding-top:62px;">欢迎登录</p></div>
			<div style="width:500px;margin:auto;background-color:azure;margin-top:20px; height:400px;border-radius：100px;">
				<h3 align="center">用户登录</h3>
				<form action="checkuser1.php" method="post" align="center" style=" margin-top:150px;">
	  <div class="control-group">
			<label for="txt_user" class="control-label">用户</label>
				<div class="controls">
					<div class="input-prepend">
						<span class="add-on">
							<i class="icon-user"></i></span>
					<input type="text" class="span2" id="txt_user" name="txt_user"/ ></div><font color="red">*yd</font>
				</div>
			
			<label for="txt_pwd" class="control-label">密码</label>
				<div class="controls">
					<div class="input-prepend">
						<span class="add-on"><i class="icon-lock"></i></span>
						<input type="text" class="span2" id="txt_pwd" name="txt_pwd"/>
					</div><font color="red">*111</font>
				</div>
			</div>
			<div>
				<input style="FONT-SIZE: 9pt"  type="submit" value="登录" name="sub_dl" onClick="return f_check(form)">&nbsp;&nbsp;&nbsp;&nbsp;
<a href="RegPro1.php" ><input type="button" value="注册" ></a>
&nbsp;&nbsp;&nbsp;&nbsp;
<a href="index1.php"><input type="button" value="返回" ></a>
&nbsp; 
			</div>
			</form>
			</div>
  <div align="center" id="footer"> 版权所有  重庆师范大学计算机与信息科学学院   17计科杨丹 QQ:1390807583  </div>
  
     </div>
	</body>
</html>

