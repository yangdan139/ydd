function showbox(){
	var show=document.getElementById("tijiao");
	show.style.display="block";
}
