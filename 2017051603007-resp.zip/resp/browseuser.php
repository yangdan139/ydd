<?php 
	session_start();
	header ("Content-type: text/html; charset=utf-8");
	   include "Conn/conn.php";//包含连接数据库的文件 
       $id=$_SESSION["uid"];
       //echo $id;
?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link href="CSS/style.css" rel="stylesheet">
<title>浏览信息</title>
<style type="text/css">
<!--
#banner{margin:0 auto;/*外边距为0，左右居中*/
			padding: 0;}
			#container{position: relative;
			margin: 0 auto; /*整个网··页版面居中*/
			padding: 0;
			background-color: transparent;
			width: 757px;/*宽度为1000px*/
			text-align: right; /*左对齐*/
			border: 2px solid white;}
.style1 {color: #FF0000}
.demo{text-shadow: 0 0 5px #fff,0 0 15px #fff,0 0 25px #fff,0 0 20px #f0f,0 0 30px #f0f;} /*添加的文字效果*/
			#banner p{text-align: center; /*左右居中*/
			padding:15px 0 0 0;
			font-size: 48px; /*字体大小*/
			color: #fff;
			font-weight: bold;
			background-image:url("images/first.jpg");} /*粗字体*/
			#banner{margin:0px; /*外边距*/
			padding:0;
			margin: -50px 0 0 0;
			width: 757px; /*banner的宽度*/
			height:
			background:#e6cbfe ;}
			#links{font-size: 1em; /*字体大小，相对大小*/
			margin:-4px 0 0 0;
			padding:0; /*内边距*/
			position: relative;
			width:757px;}
			#links ul{list-style-type:none;  /*去掉项目符号*/
			padding: 0;
			margin:0 auto;
			width: 1000px;}
			#links ul li a{text-align: center;
			/*background: url(img/pic5.jpg); /*背景图片*/
			width: 150px;
			height: 20px;
			vertical-align: middle; /*垂直居中*/
			display: inline-block; /*块显示*/
			float: left;
		  font-weight: bold; /*粗体字*/
			color: deepskyblue;
			background-color:burlywood;
			text-decoration: none; /*无装饰效果*/}
			#footer{clear: both; /*清除左右浮动*/
			font-size: 10px;
			font-weight: bold; /*粗体字*/
			width: 100%;
			padding: 3px 0px;
			text-align: center;/*文本居中*/
			margin: 0;
			background-color: #fff;} /*背景色：白色*/
			
					
		body,html{
				background-color: lightcyan;
				background-image: url("images/pic13.gif");
			}
			
			#input1{
				background: transparent;/*输入框背景透明*/
				border: none;
				color:#ffb400;
				font-size: 50px;
				font-weight: bold;
				font-family: 黑体;
				text-shadow: 0 0 5px #fff,0 0 15px #fff,0 0 25px #fff,0 0 20px #f0f,0 0 30px #f0f;
			}
-->
</style>
</head>

<script src="tijiao.js" type="text/javascript" charset="utf-8"></script>
<script language="javascript">
function check(){
	if(myform.txt_title.value==""){
		alert("博客主题名称不允许为空！");myform.txt_title.focus();return false;
	}
	if(myform.file.value==""){
		alert("文章内容不允许为空！");myform.file.focus();return false;
	}
}
			function check2(){
				var oMy = document.getElementsByTagName("ul")[1];
				oMy.className = "myUL2";//追加css类
			}
			function check1(){
				var oP = document.getElementsByTagName("ul")[2];
				oP.className = "myUL1";
				//改变css类选择器
			}
				function check3(){
				var oMy = document.getElementsByTagName("ul")[3];
				oMy.className = "myUL3";//追加css类
			}
function change(){
		if(form1.introdution.value==""){
			alert("请输入个人简介");form1.introdution.focus();return false;		
		}if(form1.introduction.value.length>=30){
			alert("个人简介不能超过30字");form1.introdution.focus();return false;		
		}
	if(form1.u_birthday.value==""){
		alert("请输入您的生日");form1.u_birthday.focus();return false;
	}		
	if(CheckDate(form1.u_birthday.value)){
		alert("请输入标准日期（如：1980/05/29或1980-05-29）");form1.u_birthday.focus();return false;
	}
	if (form1.u_email.value==""){
		alert("请输入Email地址！");form1.u_eamil.focus();return false;
	}
	var i=form1.u_email.value.indexOf("@");
	var j=form1.u_email.value.indexOf(".");
	if((i<0)||(i-j>0)||(j<0)){
		alert("您输入的Email地址不正确，请重新输入！");form1.u_email.value="";form1.u_email.focus();return false;
	}
	if(form1.u_name.value==""){
			alert("请输入用户名");form1.u_name.focus();return false;		
	}
	if(form1.u_QQ.value==""){
		alert("请输入QQ号");form1.u_QQ.focus();return false;
		
	}
	function CheckDate(INDate)
{ if (INDate=="")
    {return true;}
	subYY=INDate.substr(0,4)
	if(isNaN(subYY) || subYY<=0){
		return true;
	}
	//转换月份
	if(INDate.indexOf('-',0)!=-1){	separate="-"}
	else{
		if(INDate.indexOf('/',0)!=-1){separate="/"}
		else {return true;}
		}
		area=INDate.indexOf(separate,0)
		subMM=INDate.substr(area+1,INDate.indexOf(separate,area+1)-(area+1))
		if(isNaN(subMM) || subMM<=0){
		return true;
	}
		if(subMM.length<2){subMM="0"+subMM}
	//转换日
	area=INDate.lastIndexOf(separate)
	subDD=INDate.substr(area+1,INDate.length-area-1)
	if(isNaN(subDD) || subDD<=0){
		return true;
	}
	if(eval(subDD)<10){subDD="0"+eval(subDD)}
	NewDate=subYY+"-"+subMM+"-"+subDD
	if(NewDate.length!=10){return true;}
    if(NewDate.substr(4,1)!="-"){return true;}
    if(NewDate.substr(7,1)!="-"){return true;}
	var MM=NewDate.substr(5,2);
	var DD=NewDate.substr(8,2);
	if((subYY%4==0 && subYY%100!=0)||subYY%400==0){ //判断是否为闰年
		if(parseInt(MM)==2){
			if(DD>29){return true;}
		}
	}else{
		if(parseInt(MM)==2){
			if(DD>28){return true;}
		}	
	}
	var mm=new Array(1,3,5,7,8,10,12); //判断每月中的最大天数
	for(i=0;i< mm.length;i++){
		if (parseInt(MM) == mm[i]){
			if(parseInt(DD)>31){
				return true;
			}else{
				return false;
			}
		}
	}
   if(parseInt(DD)>30){return true;}
   if(parseInt(MM)>12){return true;}
   return false;
   }
			}
		</script>
<body >
	
<div class="container" align="center" style="background-color:palegoldenrod;"> 
	<table width="757">
		<div id="banner" style="border:1px solid peachpuff;">
			<p class="demo" >个人信息</p>
		</div></table>
		<div id="links" style="width:757px;">
	  	<ul >
	  		<li  ><a href="shouye.php" >首页</a></li>
	  		<li><a href="file.php">文章管理</a></li>
	  		<li><a href="myfans.php" >我的粉丝</a></li>
	  		<li><a href="concern.php">我的关注</a></li>
	  		<li><a href="safe.php">退出登录</a></li>
	  	</ul>
	  </div>
	  <div style="margin-top:80px; margin-bottom:0px;">
	  	<div width="560"style="height:495px;background-image:url('images/bg.jpg');" align="center" >
	  		<p align="center">
	  			文章内容
	  		</p>
	  		<div  align="center" cellpadding="2" bgcolor="palegoldenrod" style="border:2px solid palegoldenrod;width:560px;">
	  			<?php 
				                   $sql=mysql_query("select* from tb_bguser where user_id='".$id."' ");//列举文章表中的内容
									if (!$sql)
			                        {
                                       printf("Error: %s\n", mysql_error());
                                       exit();
                                    }
									$row=mysql_fetch_array($sql);
							  ?>
						
							  <table width="560"  border="1" cellpadding="1" cellspacing="1" bordercolor="#D6E7A5" bgcolor="#FFFFFF" > 
                                    <tr bgcolor="antiquewhite"> 
                             	<td width="20%">
                              用户名:</td>
                              <td width="60%" align="left"><?php echo $row['u_name'];//获取用户名 ?></td>
                            
                              </tr>
                            
                            <tr bgcolor="#FFFFFF"> 
                              <td width="20%">
                              个人简介:</td>
                              <td width="80%" align="left"><?php echo $row['introduction'];//获取用户名 ?>
                            </td>
                            </tr>
                             <tr> 
                              <td width="20%" bgcolor="antiquewhite">
                              	QQ:</td>
                              <td width="80%" align="left"><?php echo $row['u_QQ'];//获取用户名 ?></td>
                              
                            </tr>
                            <tr bgcolor="#FFFFFF">           
                              <td width="20%">
                              	出生日期:</td>
                              <td width="80%" align="left" ><?php echo $row['u_birthday'];//获取用户名 ?></td>
                              
                            </tr> 
                             <tr>
                              <td width="20%" bgcolor="antiquewhite">
                              	邮箱：</td>
                              <td width="80%" align="left"><?php echo $row['u_email'];//获取用户名 ?></td>
                           
                             </td>
                            </tr>
                                    <?php 
                                    	mysql_free_result($sql);
                                    	//mysql_close($conn);
                                    ?>
                                    </table>
                                    <div>
                            		<a href="javascript:void(0)" onclick="showbox()">修改个人信息</a>
                            	</div>
                                  </div>
                            	
                            	<div style="display:none; width:560px" id="tijiao">
                            		<form action="changgeuser.php" method="post" name="form1">
                            		<table>
                            			<tr> 
                        <td height="184" align="center" valign="middle" >
						              <table width="560" border="1" align="center" cellpadding="3" cellspacing="2" bordercolor="#FFFFFF" bgcolor="#FFFFFF" class=i_table> 
                            
                             <tr bgcolor="antiquewhite"> 
                             	<td width="100">
                             		用户名：
                              <input type="text" size="25" align="left" name="u_name" id="u_name">
                              </td>
                              </tr>
                            
                            <tr bgcolor="#FFFFFF"> 
                              <td width="100">
                              <input size="5" align="center"type="text" value="个人简介">
                              <input size="25" type="text" align="left" name="introduction" id="introduction">
                              </td>
                            </tr>
                             <tr> 
                              <td width="100" bgcolor="antiquewhite">
                              <input size="5" align="center"type="text" value="QQ">
                              <input size="25" align="left" type="text" name="u_QQ" id="u_QQ">
                              </td>
                            </tr>
                            <tr bgcolor="#FFFFFF">           
                              <td width="100">
                              <input size="5" align="center"type="text" value="出生日期">
                              <input size="25" type="text" align="left" name="u_birthday" id="u_birthday">
                              </td>
                            </tr> 
                             <tr>
                              <td width="100" bgcolor="antiquewhite">
                              <input size="5" align="center"type="text" value="邮箱">
                              <input size="25" align="left" type="text" name="u_email" id="u_email">
                              </td>
                            </tr>
                            <tr>
                            	<td>
                            		<input type="submit" value="修改" onclick="return change()">
                            			<a href="browseuser.php"><input type="button" value="取消"></a>
                            	</td>
                            </tr>
                          </table></td> 
                      </tr>
                            	</table></form>
                            	</div>
                            </div>
  </div>
   
  <div class="footer"> 版权所有  重庆师范大学计算机与信息科学学院   17计科杨丹 QQ:1390807583  </div>

</div> 
</body>
</html>

