<?php 
header ( "Content-type: text/html; charset=utf-8" ); //设置文件编码格式
session_start();

include "Conn/conn.php";
$id=$_SESSION['uid'];
?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>后台首页</title>
		<style type="text/css">
			.container{position: relative;
			margin: 0 auto; /*整个网··页版面居中*/
			padding: 0;
			background-color: transparent;
			width: 757px;/*宽度为1000px*/
			text-align: left; /*左对齐*/
			border: 2px solid white;}
	}
	.demo{text-shadow: 0 0 5px #fff,0 0 15px #fff,0 0 25px #fff,0 0 20px #f0f,0 0 30px #f0f;} /*添加的文字效果*/
			#banner p{text-align: center; /*左右居中*/
			padding:15px 0 0 0;
			font-size: 48px; /*字体大小*/
			color: #fff;
			font-weight: bold;} /*粗字体*/
			#banner{margin:0px; /*外边距*/
			padding:0;
			margin: -50px 0 0 0;
			width: 757px; /*banner的宽度*/
			height:
			background:#e6cbfe ;}
			#footer{clear: both; /*清除左右浮动*/
			font-size: 10px;
			font-weight: bold; /*粗体字*/
			width: 100%;
			padding: 3px 0px;
			text-align: center;/*文本居中*/
			margin: 0;
			background-color: #fff;} /*背景色：白色*/
			.left{
				width:200px;
				float:left;
				
			
		body,html{
				background-color: palegoldenrod;
				background-image: url("images/timg8.gif");
			}
		</style>
	</head>
	<body style="background-color: palegoldenrod;
				background-image: url('images/timg8.gif');
			">
		<div style="background-color:transparent;"class="container" align="center">
		<div id="banner" style="border:1px solid peachpuff;background-image:url('images/3.jpg'); ">
			<p class="demo" style="color:darkkhaki;">欢迎登录，管理员</p>
		</div>
		<div class="left" width="184" height="495" style="height:495px; margin-top:20px;background-image:url('images/2.jpg');">
			<ul style="list-style-type:none;">
				
				<li  style="background-image:url('images/item_out.gif'); float:left;border-radius:4px;" align="center"><img src="images/xing.gif"><a href="mydelete.php">删除的文章</a></li><br><br>
				<li></li><br><br>
				<li style="background-image:url('images/item_out.gif');float:left;border-radius:4px;" align="center"><img src="images/xing.gif"><a href="allusers.php"> 所有用户</a></li><br><br>
				<li style="background-image:url('images/item_out.gif'); border-radius:4px; width:100px;float:left;" align="center"><img src="images/xing.gif"><a href="delete_user.php">删除的用户</a></li><br><br>
				
				<li></li><br><br>
				<li style="background-image:url('images/item_out.gif');float:left;border-radius:4px;" align="center"><img src="images/xing.gif"><a href="allclass.php"> 文章分类</a></li><br><br>
				<li style="background-image:url('images/item_out.gif');float:left;border-radius:4px;" align="center"><img src="images/xing.gif"><a href="add_class.php">添加的文章分类</a></li><br><br>
				
				<li></li><br><br>
				
				<li style="background-image:url('images/item_out.gif');float:left;border-radius:4px;" align="center"><img src="images/xing.gif"><a href="safe1.php">退出登录</a></li>
			</ul>
		</div>
		<div style="margin-top:20px;height:495px;">
			<p align="center" style="margin-top:20px;font-size:20px;">
	  			所有文章
	  		</p>
	  		<table width="510" align="center" cellpadding="2" bgcolor="transparent">
	  			<form action="delete.php" name="" method="post">
	  			<tr width="510" style="font-size:12px;text-align:center;" align="center" bgcolor="burlywood">
	  				<td  style="border:1px solid peru;font-size:12px;text-align:center; " align="center">编号</td>
	  				<td style="border:1px solid peru;font-size:12px;text-align:center;" align="center">文章主题</td>
	  				<td style="border:1px solid peru;font-size:12px;text-align:center;" align="center">文章作者</td>
	  				<td  style="border:1px solid peru;font-size:12px;text-align:center;" align="center">发表时间</td>
	  				<td   style="border:1px solid peru;font-size:12px;text-align:center;" align="center">删除</td>
	  			</tr>
	  			<?php
                                       	$i=1;
                                       	    $sql=mysql_query("select  *from tb_articles,tb_bguser where tb_articles.user_id=tb_bguser.user_id");
                                       	   
                                       	    if (!$sql)
			    {
                    printf("Error: %s\n", mysql_error());
                    exit();
                }
                                       	    $row=mysql_fetch_array($sql);
                                       	    if($row=="")
                                       	    {
                                       	?>    	<tr align="center" style="text-align:center; font-size:18px;">
                                       	           <td style="text-align:center;">暂无文章！！！</td>
                                                </tr> 
                                       	<?php 
                                       	    }
                                       	    else{
                                       	    	do{
                                       	?>
                                       	          <tr width="510" style="border:1px solid peru;font-size:12px;text-align:center;" align="center">
                                       	            <td style="border:1px solid peru;font-size:12px;text-align:center;" align="center" width="25">
                                       	            	<a href="article1.php?a_id=<?php echo $row['a_id'];?>"size="2"><?php echo $i."、";?> </a>
                                       	            </td >
                                       	            <td style="border:1px solid peru;font-size:12px;text-align:center;" align="center">
                                       	            	<a href="article1.php?a_id=<?php echo $row['a_id'];?>"><?php echo $row['title'];?></a></td>
                                       	            	<td style="border:1px solid peru;font-size:12px;text-align:center;" align="center">
                                     	            	<a href="article1.php?a_id=<?php echo $row['a_id'];?>"><?php echo $row['u_name'];?></a></td>
                                     	            	
                                       	            	<td style="border:1px solid peru;font-size:12px;text-align:center;" align="center">
                                       	            	<a ><?php echo $row['time'];?></a></td>
                                       	            
                                       	            <td style="border:1px solid peru;font-size:12px;text-align:center;" align="center">
                                       	            	
                                       	            	<a href="delete.php?aid=<?php echo $row['a_id'];?>"><img src="images/A_delete.gif"></a>
                                       	          
                                       	            </td></tr> 
                                                 
                                       	<?php
                                       		$i++;    		
                                       	}while($row=mysql_fetch_array($sql));
                                       	    }
                                       	?> 
                                       	</form>
                                       	</table>
		</div>
		<div class="footer"align="center" style="background-color:peachpuff;"> 版权所有  重庆师范大学计算机与信息科学学院   17计科杨丹 QQ:1390807583</div>
		</div>
	</body>
</html>
