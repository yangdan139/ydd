<meta charset="utf-8">
	<?php
		include("conn.php");
		try{
	$pdo=new PDO($dsn,$user,$pwd);
	$pdo->query("set names utf8");
	//$query=$pdo->query("select * from tb_affiche  order by createtime desc");
	//$result=$pdo->query($query);//$result->execute();
	//$query->execute();
	$title=$_POST["txt_title"];
	$content=$_POST["txt_content"];
	$id=$_POST["id"];
	$query=$pdo->query("update tb_affiche set title='$title',content='$content' where id='$id'");
	if($query){
		echo "<script>alert('公告信息编辑成功!');history.back();</script>";
		echo "<script>window.location.href='modify.php?id=$id';</script>";
		}
		else{
			echo "<script>alert('公告信息编辑失败!');</script>";
			echo "<script>alert('公告信息编辑失败!');history.back();</script>";
		echo "<script>window.location.href='modify.php?id=$id';</script>";
		}
		$query=$pdo=NULL;
		}catch(PDOException $e){
die("Error!".$e->getMessage()."<br>");
			}
		//$result->close();
		?>
