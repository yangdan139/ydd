<?php
//xampp虚拟机和大宇服务器的mysql服务器用户和密码一样，数据库名一样
$dbms='mysql';
$host='localhost';
$dbName='a0925234204';
$user='a0925234204';
$pwd='1838625yd';
$dsn="$dbms:host=$host;dbname=$dbName";
//try{
	//$pdo=new PDO($dsn,$user,$pwd);
	//$pdo->query("set names utf8");
//}
//$mysqli=new mysqli('localhost','a0925234204','1838625yd','a0925234204',3306) ;
//mysql_select_db("a0925234204",$conn) or die("数据库访问错误".mysql_error());
//$mysqli->query("set names utf8");
?>