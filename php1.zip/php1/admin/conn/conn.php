<?php
     $conn=mysql_connect('localhost:3306','a0925234204','1838625yd') or die("数据库服务器连接错误".mysql_error());
     mysql_select_db('a0925234204',$conn) or die("数据库访问错误".mysql_error());
 	 mysql_query("set character set utf8");
     mysql_query("set names utf8");
?>