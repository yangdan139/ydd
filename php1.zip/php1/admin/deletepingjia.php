<?php
header ( "Content-type: text/html; charset=utf-8" ); //�����ļ������ʽ
include("conn/conn.php");
while(list($name,$value)=each($_POST))
 {
     $id=$value;
     mysql_query("delete from tb_pingjia where id=".$id."",$conn);
 
 }
header("location:editpinglun.php");
?>