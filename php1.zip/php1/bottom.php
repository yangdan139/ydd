<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<table width="766" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td height="4" background="images/line.gif"></td>
  </tr>
  <tr>
    <td height="44" bgcolor="#F0F0F0"><table width="100%" height="75" border="0" cellpadding="0" cellspacing="0">
      <tr>
        <td height="75" align="center"><table width="500" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td height="20" align="center">All CopyRights reserved 2007 吉林省**科技有限公司</td>
          </tr>
          <tr>
            <td height="23" align="center">客服热线：0431-8197**** E-mail：rongx**@sina.com</td>
          </tr>
        </table></td>
      </tr>
    </table>    </td>
  </tr>
</table>
