<?php
header ( "Content-type: text/html; charset=utf-8" ); //设置文件编码格式
session_start();
include "Conn/conn.php";//包含连接数据库的文件
$UserName=$_POST["txt_regname"];//获取注册页面中用户名文本框中的内容
$sql=mysql_query("select * from tb_username where regname = '$UserName'");//在用户表中查找是否有相同的用户名
$result=mysql_fetch_array($sql);
if ($result!=false){//找到有相同的用户名，则条件成立，输出语句
	echo ("<script>alert('用户名已被注册！');history.go(-1);</script>");
	exit();
}
$_SESSION["username"]=$_POST["txt_regname"];
@$u_id=$_SESSION["u_id"];//获取用户名的ID号
$regname=$_POST["txt_regname"];//获取文本框中输入的用户名
$regrealname=$_POST["txt_regrealname"];//获取文本框中输入的真实姓名
$regpwd=$_POST["txt_regpwd"];//获取密码
$regbirthday=$_POST["txt_birthday"];//获取出生日期
$regemail=$_POST["txt_regemail"];//获取邮箱
//$regcity=$_POST["txt_province"].$_POST["txt_city];
/*$regico=$_POST["txt_ico"];
$regsex=$_POST["txt_regsex"];
$regqq=$_POST["txt_regqq"];
$reghomepage=$_POST["txt_reghomepage"];
$regsign=$_POST["txt_regsign"];
$regintroduce=$_POST["txt_regintroduce"];
$ip=getenv("REMOTE_ADDR");*/
	$INS=mysql_query("Insert Into tb_username (u_id,regname,regrealname,regpwd,regbirthday,regemail,fig) values ('$u_id','$regname','$regrealname','$regpwd','$regbirthday','$regemail'，0)");//注册界面中输入的所有内容插入到用户表中对应的位置
	echo "<script> alert('用户注册成功！');window.location='index.php';</script>";
	echo "<script> window.location='file.php';</script>";
?>
