<?php
header ( "Content-type: text/html; charset=utf-8" ); //设置文件编码格式
session_start();
include "Conn/conn.php";//包含连接数据库的文件
$name=$_POST["txt_user"];//获取用户名文本框中的内容
$pwd=$_POST["txt_pwd"];//获取密码文本框中的内容
$sql=mysql_query("select * from tb_username where regname='".$name."' and regpwd='".$pwd."'");//在用户表中查找是否有相同用户名和密码的记录
$result=mysql_fetch_array($sql);
if($result!=""){
$_SESSION["fig"]=$result["fig"];
$_SESSION["username"]=$name;
?>
<script language="javascript">
	alert("登录成功");window.location.href="file.php";//如果有，则登录成功
</script>
<?php
}else{
?>
<script language="javascript">
	alert("对不起，您输入的用户名或密码不正确，请重新输入!");window.location.href="index.php";
</script>
<?php
	}
?>