<?php
header ( "Content-type: text/html; charset=utf-8" ); //设置文件编码格式
session_start();
include "Conn/conn.php";//包含连接数据库的文件
if(@$btn_tj==""){
$title=$_POST["txt_title"];//获取文章主题
@$a_id=$_SESSION["u_id"];//获取文章ID
$content=$_POST["file"];//获取文章内容
$now=date("Y-m-d H:i:s"); //获取文章发表时间
$sql="Insert Into tb_article (a_id,title,content,now) Values ('$a_id','$title','$content','$now')";//将发表的文章的所有内容按相应位置插入到文章表中
$result=mysql_query($sql);
if($result){
	echo "<script>alert('恭喜您，你的文章发表成功!!!');window.location.href='file.php';</script>";
}
else{
	echo "<script>alert('对不起，添加操作失败!!!');window.location.href='file.php';</script>";
}
}
?>

