<?php 
	session_start(); 
	include "Conn/conn.php"; //包含连接数据库的文件
	//include "check_login.php";
	@$file_id1=$_SESSION["u_id"];//获取用户名的ID
	$bool = false;
$str=array("大","更","创","天","科","客","博","技","立","新");
@$word=strlen($str);
for($i=0;$i<4;$i++){
	$num=rand(0,$word*2-1);      //$word=$word*2-1
	@$img=$img."<img src=' images/checkcode/".$num.".gif' width='16' height='16'>";    //显示随机图片
	@$pic=$pic.$str[$num];    //将图片转换成数组中的文字
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>浏览博客文章及评论</title>
<script src="JS/check.js" language="javascript">
</script>
<script language="javascript">
function r_check(){//检查评论内容是否为空
if (document.myform.txt_content.value==""){
	alert("评论内容不能为空!");myform.txt_content.focus();return false;
}
}
function d_chk(urlstr){
	if(confirm("确定要删除选中的项目吗？一旦删除将不能恢复！")){
		return true;
	}
	else
		return false;   
}
function fri_chk(){
if(confirm("确定要删除选中的项目吗？一旦删除将不能恢复！")){
		return true;
	}
	else
		return false;   
}
</script>
</head>
<body style="MARGIN-TOP: 0px; VERTICAL-ALIGN: top; PADDING-TOP: 0px; TEXT-ALIGN: center"> 
<TABLE width="757" cellPadding=0 cellSpacing=0 style="WIDTH: 755px"> 
  <TBODY> 
    <TR> 
      <TD style="VERTICAL-ALIGN: bottom; HEIGHT: 6px" colSpan=3>
	  <table width="100%" height="149"  border="0" cellpadding="0" cellspacing="0" background="images/pic2.jpg">
        <tr>
          <td height="51" align="right">
		  <br>
		  <table width="262" border="0" cellspacing="0" cellpadding="0">
            <tr align="left">
              <td width="26" height="20"><a href="index.php"></a></td>
              <td width="50" class="word_white"><a href="index.php"><span style="FONT-SIZE: 9pt; COLOR: #000000; TEXT-DECORATION: none">首  页</span></a></td>
              <td width="71"><a href="article.php"><span style="FONT-SIZE: 9pt; COLOR: #000000; TEXT-DECORATION: none">我的博客</span></a></td>
               
                      <TD style="WIDTH: 71px; COLOR: red;"><a  href="file.php" class='navlink' style="CURSOR:hand" ><span style="FONT-SIZE: 9pt; COLOR: #000000; TEXT-DECORATION: none">|添加文章</span></a></TD>
              <td width="71"><a href="<?php echo (!isset($_SESSION["username"])?'Regpro.php':'safe.php'); ?>"><span style="FONT-SIZE: 9pt; COLOR: #000000; TEXT-DECORATION: none"><?php echo (!isset($_SESSION["username"])?"注册":"安全退出"); ?></span></a></td>
              <td width="23">&nbsp;</td>
            </tr>
          </table>
		  <br></td>
        </tr>
        <tr>
          <td height="66" align="right"><p>&nbsp;</p></td>
        </tr>
        <tr>
		<form name="form" method="post" action="checkuser.php">
          <td height="20" valign="baseline">
            <table width="100%"  border="0" cellpadding="0" cellspacing="0">
              <tr>
                <td height="20" align="left" valign="baseline" style=" text-indent:50px;"> 
				<?php
		  	if(!isset($_SESSION["username"])){
		  ?>
				用户名:
                  <input  name=txt_user size="10">
密&nbsp;码:
<input  name=txt_pwd type=password style="FONT-SIZE: 9pt; WIDTH: 65px" size="6">
验证码:
<input name="txt_yan" style="FONT-SIZE: 9pt; WIDTH: 65px" size="8">
<input type="hidden" name="txt_hyan" id="txt_hyan" value="<?php echo $pic;?>">
<?php echo $img; ?> &nbsp;
<input style="FONT-SIZE: 9pt"  type="submit" value="登录" name="sub_dl" onClick="return f_check(form)">
&nbsp; 
<?php
				}else{
			?>
				<font color="red"><?php echo @$_SESSION["username"]; //获取用户名?></font>&nbsp;&nbsp;博客天空网站欢迎您的光临！！！当前时间：<font color="red"><?php echo date("Y-m-d l");//获取当前时间 ?>
</font>
			    <?
				}
			?></td>
                <td width="1%" align="center" valign="baseline">&nbsp;</td>
              </tr>
            </table> 
			</td>
		  </form>
        </tr>
      </table>
	  
		</TD> 
    </TR> 
    <TR> 
      <TD colSpan=3 valign="baseline" style="BACKGROUND-IMAGE: url( images/bg.jpg); VERTICAL-ALIGN: middle; HEIGHT: 450px; TEXT-ALIGN: center"><table width="100%" height="100%"  border="0" cellpadding="0" cellspacing="0"> 
          <tr> 
            <td height="451" align="center"><br>
              <table width="600" height="100%"  border="0" cellpadding="0" cellspacing="0"> 
                  <tr> 
                    <td height="130" align="center" valign="middle"><table width="560" border="1" align="center" cellpadding="3" cellspacing="1" bordercolor="#9CC739" bgcolor="#FFFFFF"> 
                        <tr align="left" colspan="2" > 
                          <td width="390" height="25" colspan="3" valign="top" bgcolor="#EFF7DE"> <span class="right_head"><SPAN  style="FONT-SIZE: 9pt; COLOR: #cc0033"></SPAN></span><span class="tableBorder_LTR"> 博客文章</span> </td> 
                        </tr> 
                        <td align="center" valign="top" ><table width="480" border="0" cellpadding="0" cellspacing="0"> 
                              <tr> 
                                <td>
								<?php 
									$sql=mysql_query("select * from tb_article");//列举文章表中的内容
									@$result=mysql_fetch_array($sql);
							  ?> <table width="100%"  border="1" cellpadding="1" cellspacing="1" bordercolor="#D6E7A5" bgcolor="#FFFFFF" class="i_table"> 
                                    <tr bgcolor="#FFFFFF"> 
                                      <td width="14%" align="center">博客ID号</td> 
                                      <td width="15%"><?php echo $result["a_id"];//返回文章ID ?></td> 
                                      <td width="11%" align="center">作
                                        者</td> 
                                      <td width="18%"><?php echo $_SESSION["username"];//返回作者用户名 ?></td> 
                                      <td width="12%" align="center">发表时间</td> 
                                      <td width="30%"><?php echo $result["now"];//返回发表文章时的时间 ?></td> 
                                    </tr> 
                                    <tr bgcolor="#FFFFFF"> 
                                      <td align="center">博客主题</td> 
                                      <td colspan="5">&nbsp;&nbsp;<?php echo $result["title"];//返回博客主题 ?></td> 
                                    </tr> 
                                    <tr bgcolor="#FFFFFF"> 
                                      <td align="center">文章内容</td> 
                                      <td colspan="4"><?php echo $result["content"];//获取文章内容 ?></td> 
                                      <td>
									  <?php 
									  if($_SESSION["fig"]==1){
									  	$bool=true;
									?> 
                                     
                                      <?php
										}
									 ?>
									 </td>
                                    </tr> 
                                </table></td> 
                              </tr> 
                          </table></td> 
                      </table></td> 
                  </tr> 
                  <tr> 
                    <td height="213" align="center" valign="top"><?php if (@$page=="") {$page=1;}; ?>
                    </td></tr>
        </table></TD> 
    </TR>  
  </TBODY> 
   <table  width="757" border="0" align="center" cellpadding="0" cellspacing="0">
  <div align="center"> 版权所有  重庆师范大学计算机与信息科学学院   17计科杨丹 QQ:1390807583  </div>
  </table>
</TABLE> 
</body>
</html>