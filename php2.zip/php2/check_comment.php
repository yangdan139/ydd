<?php
header ( "Content-type: text/html; charset=utf-8" ); //设置文件编码格式
session_start();
include "Conn/conn.php";//包含连接数据库的文件
if(!isset($_SESSION["username"])){
	$user = "匿名";
}else{
	$user = $_SESSION["username"];
}
if(@$_POST["submit"]=="提交"){
	$content=$_POST["txt_content"];//获取评论文本框的内容
	$a_id=$_GET["a_id"];//获取评论ID
	@$u_id=$_SESSION["u_id"];//获取用户ID

	$datetime=date("Y-m-d H:i:s");
	$INS="Insert Into tb_filecomment (a_id,u_id,filecontent,datetime) Values ('$a_id','$u_id','$content','$datetime')";//将评论的内容。ID，时间插入到评论表中
	$info=mysql_query($INS);
	if($info){
		echo "<script> alert('成功发表评论！');</script>";
		echo "<script> window.location.href='$_SERVER[HTTP_REFERER]';</script>";
	}
	else{
		echo "<script> alert('评论发表操作失败！');</script>";
		echo "<script> history.go(-1);</script>";
	}
}
?>
