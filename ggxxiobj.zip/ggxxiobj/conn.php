<?php
//xampp虚拟机和大宇服务器的mysql服务器用户和密码一样，数据库名一样
$mysqli=new mysqli('localhost','a0925234204','1838625yd','a0925234204',3306) ;
//mysql_select_db("a0925234204",$conn) or die("数据库访问错误".mysql_error());
$mysqli->query("set names utf8");
?>