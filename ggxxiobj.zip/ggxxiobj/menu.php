<!doctype html>
<html>
<head>
	<meta charset="utf-8">
		<title></title>
</head>
<body>
<table width="202" border="0" bordercolor="#0ff" cellpadding="0" cellspacing="0">
	<tr>
		<td height="34" background="images/image_03.gif">&nbsp;</td>
    </tr>
    <tr>
    	<td height="310" valign="top"><img src="img/image_09.gif" width="202" height="310" border="0" usemap="#Map"></td>
    </tr>
</table>
<map name="Map">
	<area shape="rect" coords="30,45,112,63" href="index.php">
	<area shape="rect" coords="29,71,114,90" href="search_affiche.php">
    <area shape="rect" coords="29,96,184,115" href="intercept.php">
    <area shape="rect" coords="29,122,138,140" href="page_affiche.php?page=1">
    <area shape="rect" coords="28,146,114,165" href="update_affiche.php">
    <area shape="rect" coords="29,171,117,189" href="delete_affiche.php">
</map>
</body>
</html>
