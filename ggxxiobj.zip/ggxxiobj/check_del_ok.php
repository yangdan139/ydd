<meta charset="utf-8">
<?php 
	include("conn.php");
	//$title=$_POST["txt_title"];
	//$content=$_POST["txt_content"];
	//$createtime=date("Y-m-d H:i:s");
	$id=$_GET["id"];
	$result=$mysqli->query("delete from tb_affiche where id=$id");
	if($result){
		echo "<script>alert('公告信息删除成功!');history.back();
		window.location.href='delete_affiche.php?id=$id';</script>";
		}
		else{
			echo "<script>alert('公告信息删除失败!');history.back();
			window.location.href='delete_affiche.php?id=$id';</script>";
		//echo "<script>window.location.href='index.php';</script>";
		}
		//mysql_close($conn);
		?>