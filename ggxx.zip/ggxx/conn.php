<?php
//xampp虚拟机和大宇服务器的mysql服务器用户和密码一样，数据库名一样
$conn=mysql_connect("localhost:3306","a0925234204","1838625yd") or die("数据库服务器链接错误".mysql_error());
mysql_select_db("a0925234204",$conn) or die("数据库访问错误".mysql_error());
mysql_query("set names utf8");
?>