<!DOCTYPE html>
<html lang="zh">
<head>
	<meta charset="UTF-8" />
	<title>公告信息管理</title>
</head>
<?php 
	include("conn.php");
	$title=$_POST["txt_title"];
	$content=$_POST["txt_content"];
	$createtime=date("Y-m-d H:i:s");
	$sql=mysql_query("insert into tb_affiche (title,content,createtime) values ('$title','$content','$createtime')");
	if($sql){
		echo "<script>alert('公告信息添加成功!');</script>";
		echo "<script>window.location.href='search_affiche.php';</script>";
		}
		else{
			echo "<script>alert('公告信息添加失败!');</script>";
		echo "<script>window.location.href='index.php';</script>";
		};
		mysql_close($conn);
		?>
<body>
	
</body>
</html>