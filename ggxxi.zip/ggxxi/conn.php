<?php
//xampp虚拟机和大宇服务器的mysql服务器用户和密码一样，数据库名一样
$link=mysqli_connect("localhost","a0925234204","1838625yd","a0925234204",3306) or die("数据库服务器链接错误".mysql_error());
//mysql_select_db("a0925234204",$conn) or die("数据库访问错误".mysql_error());
mysqli_query($link,"set names utf8");
?>