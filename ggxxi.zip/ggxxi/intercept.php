<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8" />
		<title>公告信息管理</title>
	<link href="css/style.css" rel="stylesheet" />
	</head>
	<body>
		<table width="828" height="522" border="0" align="center" cellpadding="0" cellspacing="0" id="__01">
			<tr>
				<td background="img/image_01.gif">&nbsp;</td>
				<td height="140" background="img/image_02.gif">&nbsp;</td>
			</tr>
			<tr>
				<td width="202" rowspan="3" valign="top">
					<table width="202" border="0" cellpadding="0" cellspacing="0">
						<tr>
							<td><?php include("menu.php");?></td>
						</tr>
					</table>
				</td>
				<td height="34" background="img/image_04.gif">&nbsp;</td>
			</tr>
			<tr>
				<td height="38" background="img/image_06.gif">&nbsp;</td>
			</tr>
			<tr>
				<td height="270" valign="top">
					<table width="626" height="100%" border="0" cellpadding="0" cellspacing="0">
						<tr>
							<td height="257" align="center" valign="top" background="img/image_08.gif">
								<table width="600" height="271" border="0" cellpadding="0" cellspacing="0">
									<tr>
										<td height="22" align="center" valign="top" class="word_orange">
											<strong>本站公告信息</strong>
										</td>
									</tr>
									<tr>
										<td height="249" align="center" valign="top"><br>
											<table width="460" border="1" align="center" cellpadding="0" cellspacing="0"bordercolor="#ffffcc" bgcolor="#dfdfdf">
												<?php
													include("conn.php");
													$sql=mysqli_query($link,"select *from tb_affiche order by createtime desc");
													$info=mysqli_fetch_array($sql);
													if(!$info){
														echo "本站暂无公告信息！";
													}else{
														do{
															?>
															<tr bgcolor="#e3e3e3">
																<td height="24" align="left" bgcolor="#ffffff">&nbsp;&nbsp;<img src="images/xing.gif" width="9" height="9">
																	<?php include_once("function.php");
																	echo chinesesubstr($info["title"],30);
																	if(strlen($info["title"])>30){
																		echo "....";
																	}
																	?>
																</td>
															</tr>
															<?php
														}while($info=mysqli_fetch_array($sql));
													}
													mysqli_free_result($sql);
													mysqli_close($link);
													?>
											</table>
										</td>
									</tr>
								</table>
							</td>
						</tr>
					</table>
				</td>
			</tr>
			<tr>
				<td bgcolor="#f0f0f0"></td>
				<td height="43" background="images/image_12.gif"></td>
			</tr>
		</table>
	</body>
</html>
