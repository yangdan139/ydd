<?php
header ( "Content-type: text/html; charset=utf-8" ); //设置文件编码格式
session_start();
include "Conn/conn.php";//包含连接数据库的文件

$auid=$_GET["auid"];//获取文章ID
//echo $auid;
$user_id=$_SESSION["uid"];
//echo $user_id;

$sql="delete from tb_concern where au_id='".$auid."' and user_id='".$user_id."'";//将发表的文章的所有内容按相应位置插入到文章表中
$result=mysql_query($sql);
if($result){
	echo "<script>alert('取消关注成功!!!');history.back();</script>";
}
else{
	echo "<script>alert('取消关注失败!!!');history.back();</script>";
}
?>