<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8" />
		<title>博客首页</title>
		<meta name="viewport" content="width=device-width,initial=scale=1.0"/>
		<link rel="stylesheet" href="../bootstrap-v2.3.2/css/bootstrap.css" />
		<link rel="stylesheet" href="../bootstrap-v2.3.2/css/bootstrap-responsive.css" />
		<script src="../bootstrap-v2.3.2/js/jquery.js"></script>
		<script src="../bootstrap-v2.3.2/js/bootstrap-dropdown.js"></script>
			<script src="../bootstrap-v2.3.2/js/bootstrap-collapse.js"></script>
		<style type="text/css">
				body{margin:10px;
				background-color:powderblue;
				}
			#footer{clear: both; /*清除左右浮动*/
			font-size: 10px;
			font-weight: bold; /*粗体字*/
			width: 100%;
			padding: 3px 0px;
			text-align: center;/*文本居中*/
			margin: 0;
			background-color: #fff;} /*背景色：白色*/
			</style>
	</head>
	<body>
		<div style="margin:auto; border:2px solid white;" align="center" class="container">
		<div  style="height:149px;background-image:url('images/footer.jpg');">
			<h2 style="text-align:center;padding-top:62px;">欢迎来到博客系统</h2></div>
		<div class="navbar" style="text-align:center;margin:auto;"align="center">
			<div class="navbar-inner">
				<a  class="btn btn-navbar" data-toggle="collapse" data-target=".navbar-responsive-collapse" >
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</a>
				<a href="index1.php" class="brand">博客系统</a>
				<ul class="nav nav-collapse collapse navbar-responsive-collapse">
					<li class="active"><a href="index1.php"style="background-color:lightgoldenrodyellow;width:150px;margin-left:20px;border-radius:8px;"><i class="icon-home"></i>首页</a></li>
					<li class="dropdown">
						<a href="#" data-toggle="dropdown" style="background-color:lightgoldenrodyellow;width:150px;margin-left:20px;border-radius:8px;">用户<b class="caret"></b></a>
						<ul class="dropdown-menu">
							<li style="background-color:bisque; border-radius:4px;"><a href="denglu1.php">登录</a></li>
							<li class="divider"></li>
							<li style="background-color:bisque; border-radius:4px;"><a href="regPro1.php">注册</a></li>
						</ul>
					</li>
					<li class="dropdown">
						<a href="#" data-toggle="dropdown" style="background-color:lightgoldenrodyellow;width:150px;margin-left:20px;border-radius:8px;">文章<b class="caret"></b></a>
						<ul class="dropdown-menu">
							<li style="background-color:bisque; border-radius:4px;"><a href="file.php">发表文章</a></li>
							<li class="divider"></li>
							<li style="background-color:bisque; border-radius:4px;"><a href="file_more.php">所有文章</a></li>
							<li class="divider"></li>
							<li style="background-color:bisque; border-radius:4px;"><a href="myfiles.php">我的文章</a></li>
						</ul>
					</li>
				</ul>
			</div>
		</div>
		
	  <div id="leftcontent" style="float:left; height:495px; margin-top:20px;background-color:antiquewhite; border-radius:20px 30px;" >
	  	<table>
	  		<tr ><table width="100%" height="100%"  border="0" cellpadding="0" cellspacing="0">
		  <tr>
			<td height="155" align="center" valign="top">
				<?php include "cale.php"; ?>	</td>
		  </tr>
		  <tr>
			<td height="125" align="center" valign="top">
			最新文章
	
			  <table  border="0" cellspacing="0" cellpadding="0">
				<tr>
				  <td><table border="0" cellspacing="0" cellpadding="0" valign="top" style="margin-top:5px;">
				  	
					 <?php
		    	include "Conn/conn.php";
				$sql=mysql_query("select a_id,title from tb_articles order by time desc limit 5");//连接文章表，显示文章主题，每页显示5行
				if (!$sql)
			    {
                    printf("Error: %s\n", mysql_error());
                    exit();
                }
				$i=1;
				$info=mysql_fetch_array($sql);
				if(!$info){
					echo "暂时没有文章!!!";
				}
				else{
					do{
			?>
						<tr>
					  <td  align="left" valign="top">
					  
					        <a href="article2_1.php?a_id=<?php echo $info['a_id'];?>"><?php echo $i."、".$info["title"];?> </a>
					       	  
					       	
					  </td>
					</tr>
			<?php
				$i++;
				}while($info=mysql_fetch_array($sql));
				}
			
			?>	
					<tr>
					  <td height="10" align="right"><a href="file_more.php"><img src=" images/more.gif"height="9" border="0">&nbsp;&nbsp;&nbsp;</a></td>
					</tr>
				  </table></td>
				</tr>
			</table></td></tr>
		  <tr>
			<td height="201" align="center" valign="top">          最新图片
			  <table border="0" cellspacing="0" cellpadding="0">
			  <tr>
				<td><table  border="0" cellspacing="0" cellpadding="0" valign="top" style="margin-top:5px;">
					
					<tr>
					  <td  rowspan="2"  align="center">&nbsp;                                        </td>
					  <td align="center"><img src="images/pic1.png"  height="80" border="0" style="border-radius:20px;"class="img-circle">                                                          </td>
					  <td  rowspan="2"  align="center">&nbsp;</td>
					</tr>
					<tr>
					  <td  align="center">图片名称：花</td>
					</tr>
			  		
				</table></td>
			  </tr>
			</table>        </td>
		  </tr>
		</table></tr>
	  	</table>
	  	
	  	
	  </div>
	  	<div style="border-radius:20px 30px;float:right; padding-top:0px;margin-top:20px; background-color:lemonchiffon;height:495px;margin-right:110px;" class="span5">
	  				<td  height="501" align="center" background="images/bg.jpg">
		<table  height="98%"  border="0" cellpadding="0" cellspacing="0">
      <tr>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td height="372" align="center"><table cellspacing=0 cellpadding=0>
        	<div  style="border:1px solid rosybrown; height: 280px; border-radius:4px;">
              
                <span style=" font-size:18px; text-align:center;"class="span2">欢迎来到博客网！</span><br>
                	<p>
                		&nbsp;&nbsp;博客，仅音译，英文名为Blogger,为Web Log的混成词。它的正式名称为网络日记；又音译为部落格或部落阁等，是使用特定的软件，在网络上出版、发表和张贴个人文章的人，或者是一种通常由个人管理、不定期张贴新的文章的网站。博客上的文章通常以网员形式出现，并根据张贴时间，以倒序排列。博客是继MSN.BBS.ICQ之后出现的第4种网络交流方式，现已受到大家的欢迎，是网络时代的个人“读者文摘”，是以超级链接为武器的网络日记，它代表着新的生活、工作和学习方式。许多博客专注在特定的课题上提供评论或新闻，其他则被作为比较个人的日记。一个典型的博客结合了文字、图像、其他博客或网站的链接及其它与主题相关的媒体，能够让读者以互动的方式留下意见，是许多博客的重要要素。大部分的博客内容以文字为主，仍有一些博客专注在艺术、摄影、视频、音乐、播客等各种主题。博客是社会媒体网络的一部分。比较著名的有新浪、网易等博客。
                	</p>
               
			  
              </div>
            <tr></tr>
          
        </table></td>
      </tr>
      <tr>
        <td height="66">&nbsp;</td>
      </tr>
    </table>
	</td>
	  	</div>
	  	<div id="footer">
	    版权所有  重庆师范大学计算机与信息科学学院   17计科杨丹 QQ:1390807583 
	  </div>
		</div>
	</body>
</html>