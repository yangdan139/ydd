<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link href="CSS/style.css"  rel="stylesheet">
<title>用户注册</title>
<meta name="viewport" content="width=device-width,initial=scale=1.0"/>
		<link rel="stylesheet" href="../bootstrap-v2.3.2/css/bootstrap.css" />
		<link rel="stylesheet" href="../bootstrap-v2.3.2/css/bootstrap-responsive.css" />
		<script src="../bootstrap-v2.3.2/js/jquery.js"></script>
		<script src="../bootstrap-v2.3.2/js/bootstrap-dropdown.js"></script>
			<script src="../bootstrap-v2.3.2/js/bootstrap-collapse.js"></script>
		<style type="text/css">
				body{margin:10px;
				background-color:powderblue;
				}
			#footer{clear: both; /*清除左右浮动*/
			font-size: 10px;
			font-weight: bold; /*粗体字*/
			width: 100%;
			padding: 3px 0px;
			text-align: center;/*文本居中*/
			margin: 0;
			background-color: #fff;} /*背景色：白色*/
			</style>
</head>
<script src="JS/check.js"  language="javascript"></script>
<body style="MARGIN-TOP: 0px; VERTICAL-ALIGN: top; PADDING-TOP: 0px; TEXT-ALIGN: center;background-color:paleturquoise; "> 
	
<div border="2" style=" width:757px; margin:0 auto; background-color:peachpuff;" > 
      	<div width="757" height="149"  border="0" cellpadding="0" cellspacing="0" style="background-image:url('images/pic2.jpg');height:149px;">
      		<p style="font-size:25px;text-align:center;padding-top:62px;">欢迎注册</p>
      	</div>
		  <br>
        
        <div style="margin-top:20px; width:757px;" align="center">
		<form name="form" method="post" action="checkuser1.php">
          <td height="20" valign="baseline">
            <table width="100%"  border="0" cellpadding="0" cellspacing="0">
              <tr>
                <td width="67%" align="left" valign="baseline" style="text-indent:10px;">
				
				用户名:
                  <input  name="txt_user" size="10"><font style="color:red;">*yd</font>
密&nbsp;码:
<input  name="txt_pwd" id="txt_pwd" type="password" style="FONT-SIZE: 10px; WIDTH: 65px;" size="5"><font style="color:red;">*111</font>

<input style="FONT-SIZE: 9pt;"  type="submit" value="登录" name="sub_dl" onClick="return f_check(form)">
&nbsp; 
				<input type="reset" value="重置" style="font-size:9pt;">
				</td>
                <td width="1%" align="center" valign="baseline">&nbsp;</td>
              </tr>
            </table> 
			</td>
		  </form>
        </div>
      <div colSpan="3" valign="baseline" style="BACKGROUND-IMAGE: url( images/bg.jpg); VERTICAL-ALIGN: middle; HEIGHT: 495px; TEXT-ALIGN: center;margin:20px;"><br>
        <form  name="myform" action="register_deal1.php" method="post" class="form-horizontal"> 
        	<h3 style="text-align:center;">用户注册</h3>
          <div border="1" align="center" style="border:1px solid plum;border-radius:5px;width:500px;margin:auto;" class="control-group"> 
            <div bgcolor="#FFFFFF" style="border-radius:5px;" class="control-lable"> 
              <lable style="border-radius:5px;float:left;width:80px;"for="txt_regname"> 用<font style="color:transparent;">时</font>户名:</lable> </div>
              <div  align="left"  class="controls" style="margin-left:-20px;">
              	<input name="txt_regname" type="text" id="txt_regname" value="" size="20" maxlength="14" align="center"> 
              </div> 
            </div> 
            <div style="height:10px;"></div>
            <div  border="1" align="center" cellpadding="3" cellspacing="2" style="border:1px solid plum;border-radius:5px;margin:auto;width:500px;" class="control-group"> 
            <div bgcolor="#FFFFFF" style="border-radius:5px;" class="control-lable"> 
              <lable  style="border-radius:5px;width:80px;float:left;"for="txt_regpwd"> 密<font style="color:transparent;">时发</font>码:</lable> </div>
              <div style="margin-left:-20px;" align="left"  class="controls">
              	<input name="txt_regpwd" type="text" id="txt_regpwd" value="" size="20" maxlength="75"> 
              英文字母或数字等不少于3位<font color="red">*</font>
              </div> 
            </div> 
            <div style="height:10px;"></div>
            <div  border="1" align="center" cellpadding="3" cellspacing="2" style="border:1px solid plum;border-radius:5px;margin:auto;width:500px;" class="control-group"> 
            <div bgcolor="#FFFFFF" style="border-radius:5px;" class="control-lable"> 
              <lable style="border-radius:5px;float:left;width:80px;"for="txt_regpwd2"> 确认密码:</lable> </div>
              <div style="margin-left:-20px;" align="left"  class="controls">
              	<input name="txt_regpwd2" type="text" id="txt_regpwd2" value="" size="20" maxlength="75" onBlur="if(this.value!=this.form.txt_regpwd.value) {alert('您两次输入的密码不一致！');myform.txt_regpwd.focus();}"> 
              		<font color="red">*</font>
              </div> 
            </div>  
            <div style="height:10px;"></div>
            <div  border="1" align="center" cellpadding="3" cellspacing="2" style="border:1px solid plum;border-radius:5px;margin:auto;width:500px;" class="control-group"> 
            <div bgcolor="#FFFFFF" style="border-radius:5px;" class="control-lable"> 
              <lable   style="border-radius:5px;float:left;width:80px;"for="txt_birthday"> 出生日期:</lable> </div>
              <div style="margin-left:-20px;" align="left"  class="controls">
              	<input name="txt_birthday" type="text" id="txt_birthday" > （日期格式为：yyyy-mm-dd）<font color="red">*</font>
              </div> 
            </div>  
            <div style="height:10px;"></div>
            <div border="1" align="center" cellpadding="3" cellspacing="2"  style="border:1px solid plum;border-radius:5px;margin:auto;width:500px;" class="control-group"> 
            <div bgcolor="#FFFFFF" style="border-radius:5px;" class="control-lable"> 
              <lable style="border-radius:5px;float:left;width:80px;"for="txt_regemail">邮<font style="color:transparent;">时的</font>箱:</lable> </div>
              <div style="margin-left:-20px;" align="left"  class="controls">
              	<input name="txt_regemail" type="text" id="txt_regemail" value="" size="35" maxlength="75"> <font color="red">*</font>
              </div> 
            </div> 
            <div style="height:10px;"></div>
            <div border="1" align="center" cellpadding="3" cellspacing="2"  style="border:1px solid plum;border-radius:5px;margin:auto;width:500px;" class="control-group"> 
            <div bgcolor="#FFFFFF" style="border-radius:5px;" class="control-lable"> 
              <lable style="border-radius:5px;float:left;width:80px;"for="txt_qq"> Q<font style="color:transparent;">时发</font>Q:</lable> </div>
              <div style="margin-left:-20px;" align="left"  class="controls">
              	<input name="txt_qq" type="text" id="txt_qq" value="" size="35" maxlength="75">QQ号码 <font color="red">*</font>
              </div> 
            </div> 
            <div style="height:10px;"></div>
            <div border="1" align="center" cellpadding="3" cellspacing="2" style="border:1px solid plum;border-radius:5px;margin:auto;width:500px;" class="control-group"> 
            <div bgcolor="#FFFFFF" style="border-radius:5px;" class="control-lable"> 
              <lable style="border-radius:5px;float:left;width:80px;"for="txt_introduction"> 个人简介:</lable> </div>
              <div style="margin-left:-20px;" align="left"  class="controls">
              	<input name="txt_introduction" type="text" id="txt_introduction" value="" size="35" maxlength="75"> 个人简介<font color="red">*</font>
              </div> 
            </div> 
            <div style="height:10px;"></div>
          <br> 
            <input type="submit" name="regsubmit" value="提 交" onClick="return check()"> &nbsp;
            <input name="Submit2" type="reset" value="重置">
            <a href="index1.php" ><input type="button" value="返回" ></a>
      </form></div>  
  <div align="center" id="footer"> 版权所有  重庆师范大学计算机与信息科学学院   17计科杨丹 QQ:1390807583  </div>
</div> 
</body>
</html>