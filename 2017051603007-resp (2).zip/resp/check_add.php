<?php
header ( "Content-type: text/html; charset=utf-8" ); //设置文件编码格式
session_start();
include "Conn/conn.php";//包含连接数据库的文件

$fanid=$_GET["fanid"];//获取文章ID
//echo $fanid;

$user_id=$_SESSION["uid"];
//echo $user_id;
$sql1=mysql_query("select * from tb_concern where user_id='".$user_id."' and au_id='".$fanid."' ");
$row=mysql_fetch_array($sql1);
if($fanid==$user_id){
	echo "<script> alert('对不起，不能关注自己！！！');history.back();</script>";
}else if($row){
	echo "<script> alert('您已经关注过该用户');history.back();</script>";
}else{
$sql="insert into tb_concern (user_id,au_id) values ('$user_id','$fanid')";
//将发表的文章的所有内容按相应位置插入到文章表中
$result=mysql_query($sql);

if($result){
	echo "<script>alert('关注成功!!!');history.back();</script>";
}
else{
	echo "<script>alert('关注失败!!!');history.back();</script>";
}
}

?>
