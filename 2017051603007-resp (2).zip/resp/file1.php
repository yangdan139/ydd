<?php 
	session_start();
	include "Conn/conn.php";
	?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link href="CSS/style.css"  rel="stylesheet">
<title>发表文章</title>
<meta name="viewport" content="width=device-width,initial=scale=1.0"/>
		<link rel="stylesheet" href="../bootstrap-v2.3.2/css/bootstrap.css" />
		<link rel="stylesheet" href="../bootstrap-v2.3.2/css/bootstrap-responsive.css" />
		<script src="../bootstrap-v2.3.2/js/jquery.js"></script>
		<script src="../bootstrap-v2.3.2/js/bootstrap-dropdown.js"></script>
			<script src="../bootstrap-v2.3.2/js/bootstrap-collapse.js"></script>
		<style type="text/css">
				body{margin:10px;
				background-color:palegoldenrod;
				background-image:url('images/pic13.gif');
				}
			#footer{clear: both; /*清除左右浮动*/
			font-size: 10px;
			font-weight: bold; /*粗体字*/
			width: 100%;
			padding: 3px 0px;
			text-align: center;/*文本居中*/
			margin: 0;
			background-color: #fff;} /*背景色：白色*/
			</style>
			<script language="javascript">
function check(){
	if(myform.txt_title.value==""){
		alert("博客主题名称不允许为空！");myform.txt_title.focus();return false;
	}
	if(myform.class.value==""){
		alert("请输入文章类型！");myform.class.focus();return false;
	}
	if(myform.file.value==""){
		alert("文章内容不允许为空！");myform.file.focus();return false;
	}
}</script>
</head>
<script src="JS/check.js"  language="javascript"></script>
<body style="margin-top: 0px; vertical-align: top; padding-top: 0px; text-align: center;background-color:palegoldenrod; "> 
	<?php
	   session_start();
	   include "Conn/conn.php";
       if(empty($_SESSION['uid']))
        {
           echo "<script>alert('您还没有登录,请先登录!');history.back();</script>";
           exit;
        }
?>
			<div style="margin:auto; border:2px solid white;" align="center" class="container">
		<div  style=" height:149px;background-image:url('images/footer.jpg');">
			<h2 style="font-size:25px;text-align:center;padding-top:62px;">发表文章</h2></div>
		<div class="navbar" style="text-align:center;margin:auto;"align="center">
			<div class="navbar-inner">
				<a  class="btn btn-navbar" data-toggle="collapse" data-target=".navbar-responsive-collapse" >
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</a>
				<a href="index1.php" class="brand">博客系统</a>
				<ul class="nav nav-collapse collapse navbar-responsive-collapse">
					<li ><a href="shouye1.php"style="background-color:lightgoldenrodyellow;border-radius:8px;"><i class="icon-home"></i>首页</a></li>
					<li class="divider-vertical"></li>
							<li style="background-color:bisque; border-radius:4px;" class="active"><a href="file1.php">发表文章</a></li>
							<li class="divider-vertical"></li>
							<li style="background-color:bisque; border-radius:4px;" ><a href="file_more1.php">所有文章</a></li>
							<li class="divider-vertical"></li>
							<li style="background-color:bisque; border-radius:4px;"><a href="myfiles1.php">我的文章</a></li>
							<li class="divider-vertical"></li>
							
					<li class="dropdown">
						<a href="#" data-toggle="dropdown" style="background-color:lightgoldenrodyellow;width:100px;margin-left:20px;border-radius:8px;">个人中心<b class="caret"></b></a>
						<ul class="dropdown-menu">
							<li style="background-color:bisque; border-radius:4px;"><a href="browseuser1.php">个人信息</a></li>
							<li class="divider"></li>
							<li style="background-color:bisque; border-radius:4px;"><a href="myfans1.php">我的粉丝</a></li>
							<li class="divider"></li>
							<li style="background-color:bisque; border-radius:4px;"><a href="concern1.php">我的关注</a></li>
						</ul>
					</li>
					<li class="divider-vertical"></li>
					<li>
						<a href="safe2.php" style="background-color:lightgoldenrodyellow;width:100px;border-radius:8px;"><i class="icon-off"></i>退出</a></li>
				</ul>
			</div>
		</div>
		<div class="span3" style="border:color:transparent; background-color:transparent;float:left;"></div>
	  <table style="border:1px solid plum;" class="span7">
	  <div style="margin-top:20px; margin-bottom:0px;">
	  	
    <TR> 
      <TD colSpan="3" valign="baseline" style="BACKGROUND-IMAGE: url( images/first.jpg); VERTICAL-ALIGN: middle; HEIGHT: 450px; TEXT-ALIGN: center"><table height="100%"  border="0" cellpadding="0" cellspacing="0">
        <tr>
          <td height="451" align="center" valign="top"><table border="0" cellpadding="0" cellspacing="0">
            <tr>
              <td height="223" align="center"><br>
			  <table border="0" cellpadding="0" cellspacing="0">
                <tr>
                  <td>
				  <form  name="myform" method="post" action="check_file.php">
				  <table  border="1" cellpadding="3" cellspacing="1" bordercolor="#D6E7A5">
                      <tr>
                        <td class="i_table" colspan="2"> <span  align="center" style="font-size:18px;font-weight:bold;">添加博客</span></td>
                      </tr>
                      <tr>
                        <td valign="top" align="right" width="14%" style="border-radius:4px;">文章主题：<br></td>
                        <td ><input name="txt_title" type="text" id="txt_title" size="48"></td>
                      </tr><tr>
                        <td valign="top" align="right" width="10%" style="border-radius:4px;">文章类型</td>
                      	<?php 
                      		$i=1;
                      		$sql=mysql_query("select* from tb_class");
                      		$row=mysql_fetch_array($sql);
                      		if(!$row){
                      			?>
                      				<td style="width:50px;float:left;">暂无文章分类</td>
                      			
                      		<?php
                      		}else
                      		{
                      			do{
                      				?>
                      				<td style="float:left;">
                      					 <input  style="float:left;"type="radio" name="class" id="class" value="<?php echo $row['classname'];?>"/><?php echo $row['classname'];?>
                      					<input type="hidden" name="classid" id="classid" value="<?php echo $row['classId'];?>" />
                      				</td>
                      				<?php
                      					$i++;
                      			}while($row=mysql_fetch_array($sql));
                      		}
                      		?>
                      </tr>
                      <tr>
                        <td align="right" style="border-radius:4px;">文章内容：</td>
                        <td >
						   <div class="file">
						   	<input	type="text" name="file" id="file" style="border:0px;height:200px; font-size:12px;">					  
						     <!--<textarea name="file" cols="75" rows="20" id="file" style="border:0px;width:520px;"></textarea> -->
						   </div> 
						</td>
                      </tr>
                      <tr align="center">
                        <td colspan="2"><input name="btn_tj" type="submit" id="btn_tj" value="提交" onClick="return check();">                          &nbsp;
                          <input name="btn_cx" type="reset" id="btn_cx" value="重写"></td>
                          <input type="hidden" id="uiid" name="uiid" value="<?php echo $_SESSION['uid']?>">
                        </tr>
                  </table>
				  </form>
				  </td>
                </tr>
              </table></td>
          </tr>
          </table>            </td>
    </tr>
</table></TD> 
    </TR></div>
   </table>
   <div class="span3" style="border:color:transparent; background-color:transparent;float:right;"></div>
  <div align="center" id="footer"> 版权所有  重庆师范大学计算机与信息科学学院   17计科杨丹 QQ:1390807583  </div>
</div> 
</body>
</html>