<?php session_start();
	include "Conn/conn.php";
	$id=$_GET["auid"];
	?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>关注作者的文章</title>
<style type="text/css">
<!--
#banner{margin:0 auto;/*外边距为0，左右居中*/
			padding: 0;}
#container{position: relative;
			margin: 0 auto; /*整个网··页版面居中*/
			padding: 0;
			background-color: transparent;
			width: 757px;/*宽度为1000px*/
			text-align: right; /*左对齐*/
			border: 2px solid white;}
.style1 {color: #FF0000}
.demo{text-shadow: 0 0 5px #fff,0 0 15px #fff,0 0 25px #fff,0 0 20px #f0f,0 0 30px #f0f;} /*添加的文字效果*/
			#banner p{text-align: center; /*左右居中*/
			padding:15px 0 0 0;
			font-size: 48px; /*字体大小*/
			color: #fff;
			font-weight: bold;
			background-image:url("images/first.jpg");} /*粗字体*/
			#banner{margin:0px; /*外边距*/
			padding:0;
			margin: -50px 0 0 0;
			width: 757px; /*banner的宽度*/
			height:
			background:#e6cbfe ;}
			#links{font-size: 1em; /*字体大小，相对大小*/
			margin:-4px 0 0 0;
			padding:0; /*内边距*/
			position: relative;
			width:757px;}
			#links ul{list-style-type:none;  /*去掉项目符号*/
			padding: 0;
			margin:0 auto;
			width: 1000px;}
			#links ul li a{text-align: center;
			/*background: url(img/pic5.jpg); /*背景图片*/
			width: 150px;
			height: 20px;
			vertical-align: middle; /*垂直居中*/
			display: inline-block; /*块显示*/
			float: left;
		  font-weight: bold; /*粗体字*/
			color: deepskyblue;
			background-color:burlywood;
			text-decoration: none; /*无装饰效果*/}
			#footer{clear: both; /*清除左右浮动*/
			font-size: 10px;
			font-weight: bold; /*粗体字*/
			width: 100%;
			padding: 3px 0px;
			text-align: center;/*文本居中*/
			margin: 0;
			background-color: #fff;} /*背景色：白色*/
			
					
		body,html{
				background-color: powderblue;
				background-image: url("images/pic13.gif");
			}
			
			#input1{
				background: transparent;/*输入框背景透明*/
				border: none;
				color:#ffb400;
				font-size: 50px;
				font-weight: bold;
				font-family: 黑体;
				text-shadow: 0 0 5px #fff,0 0 15px #fff,0 0 25px #fff,0 0 20px #f0f,0 0 30px #f0f;
			}
-->
</style>
</head>


<script language="javascript">


			function check2(){
				var oMy = document.getElementsByTagName("ul")[1];
				oMy.className = "myUL2";//追加css类
			}
			function check1(){
				var oP = document.getElementsByTagName("ul")[2];
				oP.className = "myUL1";
				//改变css类选择器
			}
				function check3(){
				var oMy = document.getElementsByTagName("ul")[3];
				oMy.className = "myUL3";//追加css类
			}
		</script>
<body >
<div id="container" align="center"  > 
	
		<div id="banner" >
			<table width="757" >
			<form name="nextForm">
			<p class="demo" >关注作者的文章</p></form>
			</table>
		</div>
	
	<div id="links" style="border:1px solid plum; height: 20px;">
	  	<ul >
	  		<li><a href="shouye.php" >首页</a></li>
	  		<li><a href="file_more.php">所有文章</a></li>
	  		<li><a href="myfiles.php" >我的文章</a></li>
	  		<li><a href="browseuser.php" >个人中心</a></li>
	  		<li><a href="safe.php">退出登录</a></li>
	  	</ul>
	</div>
	<div >
	  	<div width="560"style="height:495px;background-image:url('images/bg.jpg');" align="center" >
	  		<p align="center">关注作者的文章</p>
	  		<table width="510" align="center" cellpadding="2" bgcolor="palegoldenrod">
	  			<tr width="510" style="font-size:12px;text-align:center;" align="center" bgcolor="burlywood">
	  				<td  style="border:1px solid peru;font-size:12px;text-align:center; " align="center">编号</td>
	  				<td style="border:1px solid peru;font-size:12px;text-align:center;" align="center">文章主题</td>
	  				<td style="border:1px solid peru;font-size:12px;text-align:center;" align="center">发布时间</td>
	  				<td style="border:1px solid peru;font-size:12px;text-align:center;" align="center">取消关注</td>
	  			</tr>
	  			<?php
                                       	$i=1;
                                       	    $sql=mysql_query("select *from tb_articles where user_id='".$id."'");
                                       	    if (!$sql)
			    {
                    printf("Error: %s\n", mysql_error());
                    exit();
                }
                                       	    $row=mysql_fetch_array($sql);
                                       	    if($row=="")
                                       	    {
                                       	?>    	<tr align="center">
                                       	           <td>还作者没有写文章哦！！！</td>
                                                </tr> 
                                       	<?php 
                                       	    }
                                       	    else{
                                       	    	do{
                                       	?>
                                       	          <tr width="510" style="border:1px solid peru;font-size:12px;text-align:center;height:18px;" align="center">
                                       	            <td style="border:1px solid peru;font-size:12px;text-align:center;" align="center" width="25">
                                       	            	<a href="article.php?a_id=<?php echo $row['a_id'];?>"size="2"><?php echo $i."、";?> </a>
                                       	            </td >
                                       	            <td style="border:1px solid peru;font-size:12px;text-align:center;" align="center">
                                       	            	<a href="article.php?a_id=<?php echo $row['a_id'];?>"><?php echo $row['title'];?></a></td>
                                       	            	<td style="border:1px solid peru;font-size:12px;text-align:center;" align="center">
                                       	            	<a ><?php echo $row['time'];?></a></td>
                                       	            <td style="border:1px solid peru;font-size:12px;text-align:center;" align="center">
                                       	            	<a href="chceck_none.php?auid=<?php echo $row['user_id'];?>">取消关注</a></td>
                                                  </tr> 
                                       	<?php
                                       		$i++;    		
                                       	}while($row=mysql_fetch_array($sql));
                                       	    }
                                       	?> 
	  		</table>
	  	</div>
	</div>
  <div class="footer"> 版权所有  重庆师范大学计算机与信息科学学院   17计科杨丹 QQ:1390807583  </div>

</div> 
</body>
</html>
