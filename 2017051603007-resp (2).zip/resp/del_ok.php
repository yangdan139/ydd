
<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8" />
		<title></title>
	</head>
	<body>
		<?php    
    header ( "Content-type: text/html; charset=utf-8" ); 
	include "Conn/conn.php";//包含链接数据库的文件
	$id=$_GET["file_id"];
    $sql=mysql_query("delete from tb_articles where a_id='".$id."'");
    if (!$sql)
			    {
                    printf("Error: %s\n", mysql_error());
                    exit();
                }
	if($sql){
		echo "<script>alert('删除成功!');history.back();</script>";
	}
	else{	
		echo "<script>alert('删除操作失败！');history.back();</script>";
	}	
?> 
	</body>
</html>
		
