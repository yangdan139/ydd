<?php 
session_start();
$id=$_SESSION['uid'];
?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8" />
		<title>博客首页</title>
		<meta name="viewport" content="width=device-width,initial=scale=1.0"/>
		<link rel="stylesheet" href="../bootstrap-v2.3.2/css/bootstrap.css" />
		<link rel="stylesheet" href="../bootstrap-v2.3.2/css/bootstrap-responsive.css" />
		<script src="../bootstrap-v2.3.2/js/jquery.js"></script>
		<script src="../bootstrap-v2.3.2/js/bootstrap-dropdown.js"></script>
			<script src="../bootstrap-v2.3.2/js/bootstrap-collapse.js"></script>
		<style type="text/css">
				body{margin:10px;
				background-color:powderblue;
				background-image:url('images/timg.gif');
				}
			#footer{clear: both; /*清除左右浮动*/
			font-size: 10px;
			font-weight: bold; /*粗体字*/
			width: 100%;
			padding: 3px 0px;
			text-align: center;/*文本居中*/
			margin: 0;
			background-color: #fff;} /*背景色：白色*/
			</style>
			<script type="text/javascript">
				
			function check_class(Form){
				if(Form.search.value==""){
					alert ("请输入文章分类");
					Form.search.focus();
					return false;
				}
			}
			</script>
	</head>
	<body>
		<div style="margin:auto; border:2px solid white;background-color:papayawhip;" align="center" class="container">
		<div  style="height:149px;background-image:url('images/footer.jpg');">
			<p style="font-size:25px;text-align:center;padding-top:62px;">欢迎来到博客系统</p></div>
		<div class="navbar" style="text-align:center;margin:auto;"align="center">
			<div class="navbar-inner">
				<a  class="btn btn-navbar" data-toggle="collapse" data-target=".navbar-responsive-collapse" >
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</a>
				<a href="index1.php" class="brand">博客系统</a>
				<ul class="nav nav-collapse collapse navbar-responsive-collapse">
					<li class="active"><a href="shouye1.php"style="background-color:lightgoldenrodyellow;width:100px;margin-left:20px;border-radius:8px;"><i class="icon-home"></i>首页</a></li>
					<li class="dropdown">
						<a href="#" data-toggle="dropdown" style="background-color:lightgoldenrodyellow;width:100px;margin-left:20px;border-radius:8px;">文章管理<b class="caret"></b></a>
						<ul class="dropdown-menu">
							<li style="background-color:bisque; border-radius:4px;"><a href="file1.php">发表文章</a></li>
							<li class="divider"></li>
							<li style="background-color:bisque; border-radius:4px;"><a href="file_more1.php">所有文章</a></li>
							<li class="divider"></li>
							<li style="background-color:bisque; border-radius:4px;"><a href="myfiles1.php">我的文章</a></li>
						</ul>
					</li>
					<li class="dropdown">
						<a href="#" data-toggle="dropdown" style="background-color:lightgoldenrodyellow;width:100px;margin-left:20px;border-radius:8px;">个人中心<b class="caret"></b></a>
						<ul class="dropdown-menu">
							<li style="background-color:bisque; border-radius:4px;"><a href="browseuser1.php">个人信息</a></li>
							<li class="divider"></li>
							<li style="background-color:bisque; border-radius:4px;"><a href="myfans1.php">我的粉丝</a></li>
							<li class="divider"></li>
							<li style="background-color:bisque; border-radius:4px;"><a href="concern1.php">我的关注</a></li>
						</ul>
					</li>
					<li>
						<a href="safe2.php" style="background-color:lightgoldenrodyellow;width:100px;margin-left:20px;border-radius:8px;"><i class="icon-off"></i>退出</a></li>
				</ul>
			</div>
		</div>
		
	  <div id="leftcontent" style=" float:left; height:495px; margin-left:110px;margin-top:20px;background-color:antiquewhite; border-radius:20px 30px;" >
	  	<table>
	  		<tr ><table width="100%" height="100%"  border="0" cellpadding="0" cellspacing="0">
		  <tr>
			<td height="155" align="center" valign="top">
				<?php include "cale.php"; ?>	</td>
		  </tr>
		  <tr>
			<td height="125" align="center" valign="top">
			最新文章
	
			  <table width="200"  border="0" cellspacing="0" cellpadding="0">
				<tr>
				  <td><table width="201"  border="0" cellspacing="0" cellpadding="0" valign="top" style="margin-top:5px;">
				  	
					 <?php
		    	include "Conn/conn.php";
				$sql=mysql_query("select a_id,title from tb_articles order by time desc limit 5");//连接文章表，显示文章主题，每页显示5行
				if (!$sql)
			    {
                    printf("Error: %s\n", mysql_error());
                    exit();
                }
				$i=1;
				$info=mysql_fetch_array($sql);
				if(!$info){
					echo "暂时没有文章!!!";
				}
				else{
					do{
			?>
						<tr>
					  <td width="201" align="left" valign="top">
					  
					        <a href="article_1.php?a_id=<?php echo $info['a_id'];?>"><?php echo $i."、".$info["title"];?> </a>
					       	  
					       	
					  </td>
					</tr>
			<?php
				$i++;
				}while($info=mysql_fetch_array($sql));
				}
			
			?>	
					<tr>
					  <td height="10" align="right"><a href="file_more.php"><img src=" images/more.gif" width="27" height="9" border="0">&nbsp;&nbsp;&nbsp;</a></td>
					</tr>
				  </table></td>
				</tr>
			</table></td></tr>
		  <tr>
			<td height="201" align="center" valign="top">          最新图片
			  <table width="145"  border="0" cellspacing="0" cellpadding="0">
			  <tr>
				<td><table width="201"  border="0" cellspacing="0" cellpadding="0" valign="top" style="margin-top:5px;">
					
					<tr>
					  <td width="9" rowspan="2"  align="center">&nbsp;                                        </td>
					  <td width="147"  align="center"><img src="images/pic1.png"  width="120" height="80" border="0" style="border-radius:20px;">                                                          </td>
					  <td width="10" rowspan="2"  align="center">&nbsp;</td>
					</tr>
					<tr>
					  <td  align="center">图片名称：花</td>
					</tr>
			  		
				</table></td>
			  </tr>
			</table>        </td>
		  </tr>
		</table></tr>
	  	</table>
	  	
	  	
	  </div>
	  	<div style="border-radius:20px 30px;float:right; padding-top:0px;margin-top:20px; background-color:lemonchiffon;height:495px;margin-right:110px;" >
	  				<h3 style="text-align:center;">分类搜索文章</h3>
	  		<div style="margin-top:50px;border-radius:20px;height:200px;background-color:azure;">
	  					
	  			<form action="article3_1.php"style="height:50px;border-radius:20px;"height="200"  method="post" class="form-search">
	  				<div class="input-append">
	  					<input type="text" class="span4 search-query" name="search1" id="search1"/>
	  					<input class="btn" type="submit" value="Search">
	  					</div><!--
	  					<tr width="200">
	  				<td align="center" >
	  					<input type="text" size="20" style="font-size:14px; background-color:azure;margin-left:20px;" name="search1" id="search1"/>
	  					<input type="submit" value="搜索" onclick="return check_class();" style="font-size:14px; border:1px solid brown;font-weight:bolod;font-family: '微软雅黑';" />
	  				</td>
	  				
	  			</tr>--></form>
	  			
	  				<table style=" margin:auto;" align="center">
	  			<form width="200">
	  			<tr>
	  					<?php
	  						$i=1;
	  						$sql=mysql_query("select* from  tb_class");
                                       	   
                                       	    if (!$sql)
			    {
                    printf("Error: %s\n", mysql_error());
                    exit();
                }
                                       	    $row=mysql_fetch_array($sql);
                                       	    // $id=$row['au_id'];
                                       	  //  $sql1=mysql_query("select bgname form tb_author where au_id=$id");
                                       	   // $row1=mysql_fetch_array($sql1);
                                       	    if($row=="")
                                       	    {
                                       	?>    	<tr align="center" style="margin-top:20px;">
                                       	           <td>暂无文章分类！！！</td>
                                                </tr> 
                                       	<?php 
                                       	    }
                                       	    else{
                                       	    	do{
                                       	?>
                                       		<td>
                                       			<a href="article4_1.php?classid=<?php echo $row['classId'];?>"><?php echo $row['classname'];?></a>
                                       		</td><td>&nbsp;&nbsp;&nbsp;&nbsp;</td><td>&nbsp;&nbsp;&nbsp;&nbsp;</td>
                                       	<?php
                                       		$i++;    		
                                       	}while($row=mysql_fetch_array($sql));
                                       	    }
                                       	?> 
                                       	
                                       	</tr>
                                       	</form>
	  			
	  			
	  			</table>
	  			</div>
	  	</div>
	  	<div id="footer">
	    版权所有  重庆师范大学计算机与信息科学学院   17计科杨丹 QQ:1390807583  2018.6.30
	  </div>
		</div>
	</body>
</html>