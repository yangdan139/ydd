<?php session_start();
	include "Conn/conn.php";
	$id=$_SESSION["uid"];
	//echo $id;
	?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link href="CSS/style.css"  rel="stylesheet">
<title>修改文章</title>
<meta name="viewport" content="width=device-width,initial=scale=1.0"/>
		<link rel="stylesheet" href="../bootstrap-v2.3.2/css/bootstrap.css" />
		<link rel="stylesheet" href="../bootstrap-v2.3.2/css/bootstrap-responsive.css" />
		<script src="../bootstrap-v2.3.2/js/jquery.js"></script>
		<script src="../bootstrap-v2.3.2/js/bootstrap-dropdown.js"></script>
			<script src="../bootstrap-v2.3.2/js/bootstrap-collapse.js"></script>
		<style type="text/css">
				body{margin:10px;
				background-color:palegoldenrod;
				background-image:url('images/pic13.gif');
				}
			#footer{clear: both; /*清除左右浮动*/
			font-size: 10px;
			font-weight: bold; /*粗体字*/
			width: 100%;
			padding: 3px 0px;
			text-align: center;/*文本居中*/
			margin: 0;
			background-color: #fff;} /*背景色：白色*/
			</style>
			<script language="javascript">
function check(){
	if(myform.txt_title.value==""){
		alert("博客主题名称不允许为空！");myform.txt_title.focus();return false;
	}
	if(myform.class.value==""){
		alert("请输入文章类型！");myform.class.focus();return false;
	}
	if(myform.file.value==""){
		alert("文章内容不允许为空！");myform.file.focus();return false;
	}
}</script>
<?php
			include("Conn/conn.php");
			$cid=$_GET["file_id"];
			//echo $cid;
			$sql=mysql_query("select * from tb_articles where a_id='".$cid."' ");
			$row=mysql_fetch_object($sql);
			 if (!$sql)
			    {
                    printf("Error: %s\n", mysql_error());
                    exit();
                }
			?>
</head>
<script src="JS/check.js"  language="javascript"></script>
<body style="margin-top: 0px; vertical-align: top; padding-top: 0px; text-align: center;background-color:palegoldenrod; "> 
	<?php
	   session_start();
	   include "Conn/conn.php";
       if(empty($_SESSION['uid']))
        {
           echo "<script>alert('您还没有登录,请先登录!');history.back();</script>";
           exit;
        }
?>
			<div style="margin:auto; border:2px solid white;" align="center" class="container">
		<div  style=" height:149px;background-image:url('images/footer.jpg');">
			<h2 style="font-size:25px;text-align:center;padding-top:62px;">修改文章</h2></div>
		<div class="navbar" style="text-align:center;margin:auto;"align="center">
			<div class="navbar-inner">
				<a  class="btn btn-navbar" data-toggle="collapse" data-target=".navbar-responsive-collapse" >
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</a>
				<a href="index1.php" class="brand">博客系统</a>
				<ul class="nav nav-collapse collapse navbar-responsive-collapse">
					<li><a href="shouye1.php"style="background-color:lightgoldenrodyellow;width:100px;margin-left:20px;border-radius:8px;"><i class="icon-home"></i>首页</a></li>
					<li class="dropdown">
						<a href="#" data-toggle="dropdown" style="background-color:lightgoldenrodyellow;width:100px;margin-left:20px;border-radius:8px;">文章管理<b class="caret"></b></a>
						<ul class="dropdown-menu">
							<li style="background-color:bisque; border-radius:4px;"><a href="file1.php">发表文章</a></li>
							<li class="divider"></li>
							<li style="background-color:bisque; border-radius:4px;"><a href="file_more1.php">所有文章</a></li>
							<li class="divider"></li>
							<li style="background-color:bisque; border-radius:4px;"><a href="myfiles1.php">我的文章</a></li>
						</ul>
					</li>
					<li class="dropdown">
						<a href="#" data-toggle="dropdown" style="background-color:lightgoldenrodyellow;width:100px;margin-left:20px;border-radius:8px;">个人中心<b class="caret"></b></a>
						<ul class="dropdown-menu">
							<li style="background-color:bisque; border-radius:4px;"><a href="browseuser1.php">个人信息</a></li>
							<li class="divider"></li>
							<li style="background-color:bisque; border-radius:4px;"><a href="myfans1.php">我的粉丝</a></li>
							<li class="divider"></li>
							<li style="background-color:bisque; border-radius:4px;"><a href="concern1.php">我的关注</a></li>
						</ul>
					</li>
					<li>
						<a href="safe2.php" style="background-color:lightgoldenrodyellow;width:100px;margin-left:20px;border-radius:8px;"><i class="icon-off"></i>退出</a></li>
				</ul>
			</div>
			
		</div>
   <div class="span3" style="border:color:transparent; background-color:transparent;float:left;"></div>
		<div style="background-color:powderblue;text-align:center; height:495px;" class="span7">
	  		<table align="center" cellpadding="2" >
	  		<form action="check_modify_ok.php" name="form1" method="post">
															<table  height="212" border="0" bordercolor="f70" cellpadding="0" cellspacing="0" style="text-align:center;margin-top:30px;" align="center" valign="center">
																<tr>
																	<td align="center">文章标题：</td>
																	<td  height="31"><input name="txt_title" type="text" id="txt_title" value="<?php echo $row->title;?>" class="span3">
																	<input type="hidden" name="id" value="<?php echo $row->a_id;?>" /></td>
																</tr>
																<tr>
																	<td height="124" align="center" >文章内容：</td>
																	<td><textarea  class="span3"name="txt_content" rows="8" cols="50" id="txt_content" ><?php echo $row->a_content;?></textarea></td>
																</tr>
																<tr>
																	<td height="40" colspan="2" align="center"><input type="submit" class="btn_grey" value="修改" onClick="return check(form1);" />&nbsp;
																	<input type="reset" name="Submit2" value="重置" /></td>
																</tr>
															</table>
														</form>
	  		</table>
	  		</div>
   <div class="span3" style="border:color:transparent; background-color:transparent;float:right;"></div>
  <div align="center" id="footer"> 版权所有  重庆师范大学计算机与信息科学学院   17计科杨丹 QQ:1390807583  </div>
</div> 
</body>
</html>