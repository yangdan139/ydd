<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>博客系统</title>
<link href="CSS/style.css" rel="stylesheet"/>
</head>
	<script src="JS/check.js" language="javascript">
</script>
<body onselectstart="return false">
	<div style="background-color:blanchedalmond;">
<table width="757" height="500"   border="0" align="center" cellpadding="0" cellspacing="0" style="background-color: blanchedalmond;">
  <tr align="right" valign="top">
    <td height="149" colspan="2" background="images/pic2.jpg">
    	
    </td></tr>
    <tr>
    	<td>
	  <div width="300"  height="200" border="0" cellpadding="0" cellspacing="0" align="center" style="background-color:burlywood;">
        <h3 style="text-align: center;">用户登录</h3>
        <tr>
		<form name="form" method="post" action="checkuser.php" align="center">
          <td height="20" valign="baseline">
            <table width="100%"  border="0" cellpadding="0" cellspacing="0">
              <tr>
                <td width="32%" height="20" align="center" valign="baseline">&nbsp; </td>
                <td width="67%" align="left" valign="baseline" style="text-indent:10px;">
                	<div >
				<ul align="center" >
				<li>用户名:
                  <input  name="txt_user" id="txt_user" size="5" width="85"><sapn style="color:red;font-size:10px;">*yd</sapn>
                 </li>
                  <br><br>
<li>&nbsp;密&nbsp;码:
<input  name="txt_pwd" id="txt_pwd" type="password" style="FONT-SIZE: 10px; WIDTH: 65px" size="5">
	<sapn style="color:red;font-size=10px;">*111</sapn>
</li>
	<br><br>

&nbsp;
<input style="FONT-SIZE: 9pt"  type="submit" value="登录" name="sub_dl" onClick="return f_check(form)">&nbsp;&nbsp;&nbsp;&nbsp;
<a href="RegPro.php" ><input type="button" value="注册" class="btn_grey"></a>
&nbsp;&nbsp;&nbsp;&nbsp;
<a href="index.php"><input type="button" value="返回" class="btn_grey"></a>
&nbsp; 
</ul>
</div>
</td>
                <td width="1%" align="center" valign="baseline">&nbsp;</td>
              </tr>
            </table> 
			</td>
		  </form>
        </tr>
        </div>
       </td>
      </tr>
      <table  width="757" border="0" align="center" cellpadding="0" cellspacing="0">
  <div align="center"> 版权所有  重庆师范大学计算机与信息科学学院   17计科杨丹 QQ:1390807583  </div>
  </table>
     </table>
     </div>
	</body>
</html>
