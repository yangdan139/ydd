
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link href="CSS/style.css" rel="stylesheet">
<title>发表文章</title>
<style type="text/css">
<!--
#banner{margin:0 auto;/*外边距为0，左右居中*/
			padding: 0;}
			#container{position: relative;
			margin: 0 auto; /*整个网··页版面居中*/
			padding: 0;
			background-color: transparent;
			width: 757px;/*宽度为1000px*/
			text-align: right; /*左对齐*/
			border: 2px solid white;}
.style1 {color: #FF0000}
.demo{text-shadow: 0 0 5px #fff,0 0 15px #fff,0 0 25px #fff,0 0 20px #f0f,0 0 30px #f0f;} /*添加的文字效果*/
			#banner p{text-align: center; /*左右居中*/
			padding:15px 0 0 0;
			font-size: 48px; /*字体大小*/
			color: #fff;
			font-weight: bold;
			background-image:url("images/first.jpg");} /*粗字体*/
			#banner{margin:0px; /*外边距*/
			padding:0;
			margin: -50px 0 0 0;
			width: 757px; /*banner的宽度*/
			height:
			background:#e6cbfe ;}
			#links{font-size: 1em; /*字体大小，相对大小*/
			margin:-4px 0 0 0;
			padding:0; /*内边距*/
			position: relative;
			width:757px;}
			#links ul{list-style-type:none;  /*去掉项目符号*/
			padding: 0;
			margin:0 auto;
			width: 1000px;}
			#links ul li a{text-align: center;
			/*background: url(img/pic5.jpg); /*背景图片*/
			width: 150px;
			height: 20px;
			vertical-align: middle; /*垂直居中*/
			display: inline-block; /*块显示*/
			float: left;
		  font-weight: bold; /*粗体字*/
			color: deepskyblue;
			background-color:burlywood;
			text-decoration: none; /*无装饰效果*/}
			#footer{clear: both; /*清除左右浮动*/
			font-size: 10px;
			font-weight: bold; /*粗体字*/
			width: 100%;
			padding: 3px 0px;
			text-align: center;/*文本居中*/
			margin: 0;
			background-color: #fff;} /*背景色：白色*/
			
					
		body,html{
				background-color: lightcyan;
				background-image: url("images/pic13.gif");
			}
			
			#input1{
				background: transparent;/*输入框背景透明*/
				border: none;
				color:#ffb400;
				font-size: 50px;
				font-weight: bold;
				font-family: 黑体;
				text-shadow: 0 0 5px #fff,0 0 15px #fff,0 0 25px #fff,0 0 20px #f0f,0 0 30px #f0f;
			}
-->
</style>
</head>


<script language="javascript">
function check(){
	if(myform.txt_title.value==""){
		alert("博客主题名称不允许为空！");myform.txt_title.focus();return false;
	}
	if(myform.class.value==""){
		alert("请输入文章类型！");myform.class.focus();return false;
	}
	if(myform.file.value==""){
		alert("文章内容不允许为空！");myform.file.focus();return false;
	}
}var msg=" publish article";
			var interval = 400;
			var seq=0;
			function LenScroll(){
				document.nextForm.lenText.value = msg.substring(seq,msg.length) + "  "+msg;
				seq++;
				if(seq>msg.length)
				seq=0;
				window.setTimeout("LenScroll();",interval);
			}
			function check2(){
				var oMy = document.getElementsByTagName("ul")[1];
				oMy.className = "myUL2";//追加css类
			}
			function check1(){
				var oP = document.getElementsByTagName("ul")[2];
				oP.className = "myUL1";
				//改变css类选择器
			}
				function check3(){
				var oMy = document.getElementsByTagName("ul")[3];
				oMy.className = "myUL3";//追加css类
			}
		</script>
<body onload="LenScroll()">
	<?php
	   session_start();
	   include "Conn/conn.php";
       if(empty($_SESSION['uid']))
        {
           echo "<script>alert('您还没有登录,请先登录!');history.back();</script>";
           exit;
        }
?>
<div class="container" align="center"> 
	<table width="757" >
		<div id="banner" style="border:1px solid peachpuff;">
			<form name="nextForm">
			<p class="demo" >publish article</p></form
		</div></table>
		<div id="links" style="width:757px;"style="border:1px solid plum;">
	  	<ul >
	  		<li  ><a href="shouye.php" >首页</a></li>
	  		<li><a href="file_more.php">所有文章</a></li>
	  		<li><a href="myfiles.php" >我的文章</a></li>
	  		<li><a href="browseuser.php" >个人中心</a></li>
	  		<li><a href="safe.php">退出登录</a></li>
	  	</ul>
	  </div>
	  <table style="border:1px solid plum;" width="757">
	  <div style="margin-top:80px; margin-bottom:0px;">
	  	
    <TR> 
      <TD colSpan=3 valign="baseline" style="BACKGROUND-IMAGE: url( images/first.jpg); VERTICAL-ALIGN: middle; HEIGHT: 450px; TEXT-ALIGN: center"><table width="100%" height="100%"  border="0" cellpadding="0" cellspacing="0">
        <tr>
          <td height="451" align="center" valign="top"><table width="640"  border="0" cellpadding="0" cellspacing="0">
            <tr>
              <td width="613" height="223" align="center"><br>
			  <table width="500" border="0" cellpadding="0" cellspacing="0">
                <tr>
                  <td>
				  <form  name="myform" method="post" action="check_file.php">
				  <table width="630" border="1" cellpadding="3" cellspacing="1" bordercolor="#D6E7A5">
                      <tr>
                        <td class="i_table" colspan="2"> <span  align="center" style="font-size:18px;font-weight:bold;">添加博客</span></td>
                      </tr>
                      <tr>
                        <td valign="top" align="right" width="14%" style="border-radius:4px;">文章主题：<br></td>
                        <td width="50%"><input name="txt_title" type="text" id="txt_title" size="48"></td>
                      </tr><tr>
                        <td valign="top" align="right" width="10%" style="border-radius:4px;">文章类型</td>
                      	<?php 
                      		$i=1;
                      		$sql=mysql_query("select* from tb_class");
                      		$row=mysql_fetch_array($sql);
                      		if(!$row){
                      			?>
                      				<td style="width:50px;float:left;">暂无文章分类</td>
                      			
                      		<?php
                      		}else
                      		{
                      			do{
                      				?>
                      				<td style="width:50px;float:left;">
                      					 <input  style="width:20px;float:left;"type="radio" name="class" id="class" value="<?php echo $row['classname'];?>"/><?php echo $row['classname'];?>
                      					<input type="hidden" name="classid" id="classid" value="<?php echo $row['classId'];?>" />
                      				</td>
                      				<?php
                      					$i++;
                      			}while($row=mysql_fetch_array($sql));
                      		}
                      		?>
                      </tr>
                      <tr>
                        <td align="right" width="14%"style="border-radius:4px;">文章内容：</td>
                        <td width="86%">
						   <div class="file">
						   	<input	type="text" name="file" id="file" style="border:0px;width:520px;height:200px; font-size:12px;">					  
						     <!--<textarea name="file" cols="75" rows="20" id="file" style="border:0px;width:520px;"></textarea> -->
						   </div> 
						</td>
                      </tr>
                      <tr align="center">
                        <td colspan="2"><input name="btn_tj" type="submit" id="btn_tj" value="提交" onClick="return check();">                          &nbsp;
                          <input name="btn_cx" type="reset" id="btn_cx" value="重写"></td>
                          <input type="hidden" id="uiid" name="uiid" value="<?php echo $_SESSION['uid']?>">
                        </tr>
                  </table>
				  </form>
				  </td>
                </tr>
              </table></td>
          </tr>
          </table>            </td>
    </tr>
</table></TD> 
    </TR></div>
   </table>
  <div class="footer" id="footer"> 版权所有  重庆师范大学计算机与信息科学学院   17计科杨丹 QQ:1390807583  </div>

</div> 
</body>
</html>