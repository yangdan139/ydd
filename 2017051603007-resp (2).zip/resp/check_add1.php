<?php
header ( "Content-type: text/html; charset=utf-8" ); //设置文件编码格式
session_start();
include "Conn/conn.php";//包含连接数据库的文件

$classname=$_POST['name1'];
//echo $classname;
$ad_id=$_SESSION["uid"];
//echo $ad_id;
$sql1=mysql_query("select *from tb_class where classname='".$classname."'");
if (!$sql1)
			    {
                    printf("Error: %s\n", mysql_error());
                    exit();
                }
$sql=mysql_query("insert into tb_class (ad_id,classname) values ('$ad_id','$classname')");//添加文章分类

 if (!$sql)
			    {
                    printf("Error: %s\n", mysql_error());
                    exit();
               }
$result=mysql_fetch_array($sql1);
if($result){
	echo "<script> alert('已有该文章分类，请重新输入！！');window.location.href='allclass.php';</script>";
}
else if($sql){
	echo "<script>alert('分类添加成功!!!');history.back();</script>";
}
else{
	echo "<script>alert('分类添加失败失败!!!');history.back();</script>";
}

?>