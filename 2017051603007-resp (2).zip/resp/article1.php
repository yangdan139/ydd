<?php session_start();
	include "Conn/conn.php";
	$id=$_GET["a_id"];
	?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>浏览文章</title>
<style type="text/css">
<!--
#banner{margin:0 auto;/*外边距为0，左右居中*/
			padding: 0;}
#container{position: relative;
			margin: 0 auto; /*整个网··页版面居中*/
			padding: 0;
			background-color: transparent;
			width: 757px;/*宽度为1000px*/
			text-align: right; /*左对齐*/
			border: 2px solid white;}
.style1 {color: #FF0000}
.demo{text-shadow: 0 0 5px #fff,0 0 15px #fff,0 0 25px #fff,0 0 20px #f0f,0 0 30px #f0f;} /*添加的文字效果*/
			#banner p{text-align: center; /*左右居中*/
			padding:15px 0 0 0;
			font-size: 48px; /*字体大小*/
			color: #fff;
			font-weight: bold;
			background-image:url("images/first.jpg");} /*粗字体*/
			#banner{margin:0px; /*外边距*/
			padding:0;
			margin: -50px 0 0 0;
			width: 757px; /*banner的宽度*/
			height:
			background:#e6cbfe ;}
			#links{font-size: 1em; /*字体大小，相对大小*/
			margin:-4px 0 0 0;
			padding:0; /*内边距*/
			position: relative;
			width:757px;}
			#links ul{list-style-type:none;  /*去掉项目符号*/
			padding: 0;
			margin:0 auto;
			width: 1000px;}
			#links ul li a{text-align: center;
			/*background: url(img/pic5.jpg); /*背景图片*/
			width: 150px;
			height: 20px;
			vertical-align: middle; /*垂直居中*/
			display: inline-block; /*块显示*/
			float: left;
		  font-weight: bold; /*粗体字*/
			color: deepskyblue;
			background-color:burlywood;
			text-decoration: none; /*无装饰效果*/}
			#footer{clear: both; /*清除左右浮动*/
			font-size: 10px;
			font-weight: bold; /*粗体字*/
			width: 100%;
			padding: 3px 0px;
			text-align: center;/*文本居中*/
			margin: 0;
			background-color: #fff;} /*背景色：白色*/
			
					
		body,html{
				background-color: thistle;
				background-image: url("images/pic13.gif");
			}
			.left{
				width:200px;
				float:left;
				
-->
</style>
</head>


<script language="javascript">


			function check2(){
				var oMy = document.getElementsByTagName("ul")[1];
				oMy.className = "myUL2";//追加css类
			}
			function check1(){
				var oP = document.getElementsByTagName("ul")[2];
				oP.className = "myUL1";
				//改变css类选择器
			}
				function check3(){
				var oMy = document.getElementsByTagName("ul")[3];
				oMy.className = "myUL3";//追加css类
			}
			function r_check(){
            if (document.myform.addcon.value=="")
            {
	            alert("评论内容不能为空!");
	            myform.addcon.focus();
	            return false;
            }
     }
		</script>
<body >
	
<div id="container" align="center"  > 
	<div id="banner" style="border:1px solid peachpuff;background-image:url('images/3.jpg'); ">
			<p class="demo" style="color:darkkhaki;">欢迎登录，管理员</p>
		</div>
		<div class="left" width="184" height="495" style="height:495px; margin-top:20px;background-image:url('images/2.jpg');width:184px;">
			<ul style="list-style-type:none;">
				<li style="background-image:url('images/item_out.gif'); float:left;border-radius:4px;" align="center"><img src="images/xing.gif"><a href="index_ad.php"> 所有文章</a></li><br><br>
				<li  style="background-image:url('images/item_out.gif'); float:left;border-radius:4px;" align="center"><img src="images/xing.gif"><a href="mydelete.php">删除的文章</a></li><br><br>
				<li></li><br><br>
				<li style="background-image:url('images/item_out.gif'); border-radius:4px; width:100px;float:left;" align="center"><img src="images/xing.gif"><a href="delete_user.php">删除的用户</a></li><br><br>
				
				<li></li><br><br>
				<li style="background-image:url('images/item_out.gif');float:left;border-radius:4px;" align="center"><img src="images/xing.gif"><a href="allclass.php"> 文章分类</a></li><br><br>
				<li style="background-image:url('images/item_out.gif');float:left;border-radius:4px;" align="center"><img src="images/xing.gif"><a href="add_class.php">添加的文章分类</a></li><br><br>
				
				<li></li><br><br>
				
				<li style="background-image:url('images/item_out.gif');float:left;border-radius:4px;" align="center"><img src="images/xing.gif"><a href="safe1.php">退出登录</a></li>
			</ul>
		</div>
	<div >
	  	<div width="500"style="height:495px;background-image:url('images/bg.jpg');float:right;margin-top:20px;" align="center" >
	  		<p align="center">
	  			文章内容
	  		</p>
	  		<div  align="center" cellpadding="2" bgcolor="palegoldenrod" style="border:2px solid palegoldenrod;width:560px;">
	  			<?php 
				                   $sql=mysql_query("select *from  tb_articles join tb_bguser on tb_articles.user_id=tb_bguser.user_id where tb_articles.a_id='".$id."'");//列举文章表中的内容
									if (!$sql)
			                        {
                                       printf("Error: %s\n", mysql_error());
                                       exit();
                                    }
									$result=mysql_fetch_array($sql);
							  ?>
						
							  <table width="500"  border="1" cellpadding="1" cellspacing="1" bordercolor="#D6E7A5" bgcolor="#FFFFFF" > 
                                    <tr bgcolor="#FFFFFF"> 
                                      <td width="20%" align="center">文章ID号</td> 
                                      <td width="15%"><?php echo $result["a_id"];//返回文章ID ?></td> 
                                      <td width="11%" align="center">作者</td> 
                                      <td width="18%"><?php echo $result["u_name"];//返回作者用户名 ?></td> 
                                      <td width="20%" align="center">发表时间</td> 
                                      <td width="30%"><?php echo $result["time"];//返回发表文章时的时间 ?></td> 
                                    </tr> 
                                    <tr bgcolor="#FFFFFF"> 
                                      <td align="center" width="20%">博客主题</td> 
                                      <td colspan="5">&nbsp;&nbsp;<?php echo $result["title"];//返回博客主题 ?></td> 
                                    </tr> 
                                    <tr bgcolor="#FFFFFF"> 
                                      <td align="center">文章内容</td> 
                                      <td colspan="5"><?php echo $result["a_content"];//获取文章内容 ?></td> 
                                    </tr>
                                    <?php 
                                    	mysql_free_result($sql);
                                    	//mysql_close($conn);
                                    ?>
                                   <?php 
									$sql=mysql_query("select * from tb_comment join tb_bguser on tb_comment.user_id=tb_bguser.user_id and tb_comment.a_id='".$id."'");//列举文章表中的评论
									if (!$sql)
			                        {
                                        printf("Error: %s\n", mysql_error());
                                        exit();
                                    }
									$row=mysql_fetch_array($sql);
							        ?>
                                    <tr bgcolor="#FFFFFF">
                                    	<td>评论</td>
                                    </tr>
                                    <?php
                                    	if(!$row)
                                    	{
                                    ?>		<tr><td colspan="6" align="center"><?php echo"暂无评价！！！";?></td></tr>
                                    <?php	}else{
                                    		do{
                                    ?>			<tr>
                                    	            <td>评论人：</td>
                                    	            <td colspan="6"width="30" style="width:30px;float:left;"> <?php echo $row["u_name"];?> </td>
                                    	            <td style="margin-left:100px;" width="20%">评论时间：</td>
                                    	            <td colspan="6"style="width:100px;float:right;"><?php echo $row["c_date"];?></td>
                                    	            <td style="border:transparent;"></td>
                                    	            <td colspan="6"style="width:100px;float:right;"><a href="del_comment.php?c_id=<?php echo $row['c_id'];?>"><img src="images/A_delete.gif"></a></td>
                                                </tr>
                                    <tr>
                                    	<td style="width:100px;" >评论内容：</td>
                                    	<td colspan="6" ><?php echo $row["c_content"];?></td>
                                    </tr>
                                    <?php		}while($row=mysql_fetch_array($sql));
                                    	}
                                    ?>
	  		</table>
	  		</div>
	  	</div>
	</div>
  <div class="footer"> 版权所有  重庆师范大学计算机与信息科学学院   17计科杨丹 QQ:1390807583  </div>

</div> 
</body>
</html>
