<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link href="CSS/style.css"  rel="stylesheet">
<title>用户注册</title>
</head>
<script src="JS/check.js"  language="javascript"></script>
<BODY style="MARGIN-TOP: 0px; VERTICAL-ALIGN: top; PADDING-TOP: 0px; TEXT-ALIGN: center;background-color:paleturquoise; "> 
	
<div border="2" style=" width:757px; margin:0 auto; background-color:peachpuff;" >
  <TABLE width="757" cellPadding=0 cellSpacing=0 style="WIDTH: 755px; " align="center"> 
    <TBODY > 
      <TR> <TD style="VERTICAL-ALIGN: bottom; HEIGHT: 6px" colSpan=3 background="images/pic2.jpg">
      	<div width="100%"height="149"  border="0" cellpadding="0" cellspacing="0">
      		<p style="font-size:25px;text-align:center;">欢迎注册</p>
      	</div>
		  <br>
        
        <tr>
		<form name="form" method="post" action="checkuser.php">
          <td height="20" valign="baseline">
            <table width="100%"  border="0" cellpadding="0" cellspacing="0">
              <tr>
                <td width="32%" height="20" align="center" valign="baseline">&nbsp; </td>
                <td width="67%" align="left" valign="baseline" style="text-indent:10px;">
				
				用户名:
                  <input  name="txt_user" size="10">
密&nbsp;码:
<input  name="txt_pwd" id="txt_pwd" type="password" style="FONT-SIZE: 10px; WIDTH: 65px;" size="5">

<input style="FONT-SIZE: 9pt;"  type="submit" value="登录" name="sub_dl" onClick="return f_check(form)">
&nbsp; 
				<input type="reset" value="重置" style="font-size:9pt;">
				</td>
                <td width="1%" align="center" valign="baseline">&nbsp;</td>
              </tr>
            </table> 
			</td>
		  </form>
        </tr></TD> 
      </TR> 
    <TR> 
      <TD colSpan="3" valign="baseline" style="BACKGROUND-IMAGE: url( images/bg.jpg); VERTICAL-ALIGN: middle; HEIGHT: 450px; TEXT-ALIGN: center"><br>
        <form  name="myform" action="register_deal.php" method="post"> 
          <table width="85%" border="1" align="center" cellpadding="3" cellspacing="2" bordercolor="#FFFFFF" bgcolor="#FFFFFF" style="border:1px solid plum;border-radius:5px;"> 
            <tr align="left" bgcolor="#EFF7DE"> 
              <td height="22" colspan="2" bgcolor="#EFF7DE" class="right_head"><span class="tableBorder_LTR">必填内容</span></td> 
            </tr> 
            <tr bgcolor="#FFFFFF" style="border:1px solid red;border-radius:5px;"> 
              <td width="22%" align="right" valign="middle" class="f_one" style="border:1px solid plum;border-radius:5px;"> 用户名</td> 
              <td width="78%" align="left"  class="f_one"><input name="txt_regname" type="text" id="txt_regname" value="" size="20" maxlength="14"> 
               <a href="#" onClick="javacript:openwin(myform.txt_regname.value)">[检测用户]</a> <font color="red">*</font>
              <div id="check_info"></div></td> 
            </tr> 
            <tr> 
            <tr bgcolor="#FFFFFF"> 
              <td align="right" valign="middle"style="border:1px solid plum;border-radius:5px;" > 密码</td> 
              <td align="left"> <input name="txt_regpwd"type="password" id="txt_regpwd" size="20 " maxlength="75"> 
              英文字母或数字等不少于3位<font color="red">*</font></td> 
            </tr> 
            <tr bgcolor="#FFFFFF"> 
              <td align="right" valign="middle"style="border:1px solid plum;border-radius:5px;"> 确认密码</td> 
              <td align="left" > <input name="txt_regpwd2" type="password" id="txt_regpwd2" size="20 " maxlength="75" onBlur="if(this.value!=this.form.txt_regpwd.value) {alert('您两次输入的密码不一致！');myform.txt_regpwd.focus();}"> 
              <font color="red">*</font></td> 
            </tr> 
            <tr bgcolor="#FFFFFF"> 
              <td align="right"style="border:1px solid plum;border-radius:5px;" > 出生日期</td> 
              <td align="left" > <span class="word_grey"> 
                <input name="txt_birthday" type="text" id="txt_birthday"> 
              （日期格式为：yyyy-mm-dd）<font color="red">*</font></span></td> 
            </tr> 
            <tr bgcolor="#FFFFFF"> 
              <td align="right" valign="middle"style="border:1px solid plum;border-radius:5px;"> Email(邮箱)</td> 
              <td align="left"  > <input name="txt_regemail" type="text" id="txt_regemail" value='' size="35" maxlength="75"> 
              <font color='#000000'>公开邮箱 <font color="red">*</font></font> </td> 
            </tr> 
            <tr bgcolor="#FFFFFF"> 
              <td align="right" valign="middle" style="border:1px solid plum;border-radius:5px;"> QQ</td> 
              <td align="left"  > <input name="txt_qq" type="text" id="txt_qq" value="" size="35" maxlength="75"> 
              <font color='#000000'>QQ号码 <font color="red">*</font></font> </td> 
            </tr> 
            <tr bgcolor="#FFFFFF"> 
              <td align="right" valign="middle" style="border:1px solid plum;border-radius:5px;"> 个人简介</td> 
              <td align="left"  > <input name="txt_introduction" type="text" id="txt_introduction" value="" size="35" maxlength="75"> 
              <font color="#000000">个人简介<font color="red">*</font></font> </td> 
            </tr>
          </table> 
          <br> 
            <input type="submit" name="regsubmit" value="提 交"class="btn_grey" onClick="return check()"> &nbsp;
            <input name="Submit2" type="reset" class="btn_grey" value="重 填">
            <a href="index.php" ><input type="button" value="返回" class="btn_grey"></a>
      </form></TD> 
    </TR> 
  </TBODY> 
   <table  width="757" border="0" align="center" cellpadding="0" cellspacing="0">
  <div align="center"> 版权所有  重庆师范大学计算机与信息科学学院   17计科杨丹 QQ:1390807583  </div>
  </table>
</TABLE> 
</body>
</html>