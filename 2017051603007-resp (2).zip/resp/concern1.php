<?php 
	session_start();
	header ("Content-type: text/html; charset=utf-8");
	   include "Conn/conn.php";//包含连接数据库的文件 
       $id=$_SESSION["uid"];
       //echo $id;
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link href="CSS/style.css"  rel="stylesheet">
<title>我的关注</title>
<meta name="viewport" content="width=device-width,initial=scale=1.0"/>
		<link rel="stylesheet" href="../bootstrap-v2.3.2/css/bootstrap.css" />
		<link rel="stylesheet" href="../bootstrap-v2.3.2/css/bootstrap-responsive.css" />
		<script src="../bootstrap-v2.3.2/js/jquery.js"></script>
		<script src="../bootstrap-v2.3.2/js/bootstrap-dropdown.js"></script>
		
			<script src="../bootstrap-v2.3.2/js/bootstrap-collapse.js"></script>
		<style type="text/css">
				body{margin:10px;
				background-color:palegoldenrod;
				background-image:url('images/timg8.gif');
				}
			#footer{clear: both; /*清除左右浮动*/
			font-size: 10px;
			font-weight: bold; /*粗体字*/
			width: 100%;
			padding: 3px 0px;
			text-align: center;/*文本居中*/
			margin: 0;
			background-color: #fff;} /*背景色：白色*/
			</style>
</head>
<body style="margin-top: 0px; vertical-align: top; padding-top: 0px; text-align: center;background-color:palegoldenrod; "> 
	<?php
	   session_start();
	   include "Conn/conn.php";
       if(empty($_SESSION['uid']))
        {
           echo "<script>alert('您还没有登录,请先登录!');history.back();</script>";
           exit;
        }
?>
			<div style="margin:auto; border:2px solid white;" align="center" class="container">
		<div  style=" height:149px;background-image:url('images/footer.jpg');">
			<h2 style="font-size:25px;text-align:center;padding-top:62px;">我的关注</h2></div>
		<div class="navbar" style="text-align:center;margin:auto;"align="center">
			<div class="navbar-inner">
				<a  class="btn btn-navbar" data-toggle="collapse" data-target=".navbar-responsive-collapse" >
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</a>
				<a href="index1.php" class="brand">博客系统</a>
				<ul class="nav nav-collapse collapse navbar-responsive-collapse">
					<li ><a href="shouye1.php"style="background-color:lightgoldenrodyellow;border-radius:8px;"><i class="icon-home"></i>首页</a></li>
					<li class="dropdown">
						<a href="#" data-toggle="dropdown" style="background-color:lightgoldenrodyellow;width:100px;margin-left:20px;border-radius:8px;">文章管理<b class="caret"></b></a>
						<ul class="dropdown-menu">
							<li style="background-color:bisque; border-radius:4px;"><a href="file1.php">发表文章</a></li>
							<li class="divider"></li>
							<li style="background-color:bisque; border-radius:4px;"><a href="file_more1.php">所有文章</a></li>
							<li class="divider"></li>
							<li style="background-color:bisque; border-radius:4px;"><a href="myfiles1.php">我的文章</a></li>
						</ul>
					</li>
							<li class="divider-vertical"></li>
							
				
							<li style="background-color:bisque; border-radius:4px;"><a href="browseuser1.php">个人信息</a></li>
							<li class="divider-vertical"></li>
							<li style="background-color:bisque; border-radius:4px;" ><a href="myfans1.php">我的粉丝</a></li>
							<li class="divider-vertical"></li>
							<li style="background-color:bisque; border-radius:4px;" class="active"><a href="concern1.php">我的关注</a></li>
					<li class="divider-vertical"></li>
					<li>
						<a href="safe2.php" style="background-color:lightgoldenrodyellow;width:100px;border-radius:8px;"><i class="icon-off"></i>退出</a></li>
				</ul>
			</div>
		</div>
		<div class="span3" style="border:color:transparent; background-color:transparent;float:left;"></div>
	  <div style="border:2px solid tan;margin-top:20px; background-color:khaki; height:495px; margin:0 auto;text-align:center;" class="span7" align="center" >
	 			<h1 align="center" style="font-size:20px;">我的关注</h1>
	 	<table style=" margin:20px; text-align:center;"align="center">
	 		<form name="form2" method="post">
	 			<thead  style="font-size:12px;text-align:center;" align="center" >
	  				<th  style="border:1px solid peru;font-size:12px;text-align:center; " align="center" bgcolor="burlywood">序号</th>
	  				<th class="span1"style="background:transparent;"></th>
	  				<th style="border:1px solid peru;font-size:12px;text-align:center;" align="center" bgcolor="burlywood">博客名</th>
	  			<th class="span1"style="background:transparent;"></th>
	  				<th  style="border:1px solid peru;font-size:12px;text-align:center;" align="center" bgcolor="burlywood">个人说明</th>
	  				<th class="span1"style="background:transparent;"></th>
	  				<th   style="border:1px solid peru;font-size:12px;text-align:center;" align="center" bgcolor="burlywood">取消关注</th>
	  				<th class="span1"style="background:transparent;"></th>
	  				<th   style="border:1px solid peru;font-size:12px;text-align:center;" align="center" bgcolor="burlywood">博客文章</th>
	  				
	  			</thead>
	  			<tbody>
	 		<?php
                                       	$i=1;
                                       	
                                       	    $sql=mysql_query("select * from tb_bguser join tb_concern on tb_concern.au_id=tb_bguser.user_id where tb_concern.user_id='".$id."'");
                                       	    if (!$sql)
			    {
                    printf("Error: %s\n", mysql_error());
                    exit();
                }
                                       	    $row=mysql_fetch_array($sql);
                                       	    if(!$row)
                                       	    {
                                       	?>    	<tr align="center">
                                       	           <td>暂无关注！</td>
                                                </tr> 
                                       	<?php 
                                       	    }
                                       	    else{
                                       	    	do{
                                       	?>
                                       	          <tr  style="border:1px solid peru;font-size:12px;text-align:center;" align="center">
                                       	            <td style="border:1px solid peru;font-size:12px;text-align:center;" align="center" >
                                       	            	<a size="2"><?php echo $i."、";?> </a>
                                       	            </td >
                                       	            <td class="span1"style="background:transparent;"></td>
                                       	            <td style="border:1px solid peru;font-size:12px;text-align:center;margin-left:10px; height:15px;" >
                                       	            	<?php echo $row['u_name'];?></td>
                                       	            <td class="span1"style="background:transparent;"></td>
                                       	            	
                                       	            	
                                       	            <td style="border:1px solid peru;font-size:12px;text-align:center; margin-left:10px;height:15px;"  >
                                       	            	
                                       	            		<?php echo $row['introduction']; ?>
                                       	            	</td>
                                       	            <td class="span1"style="background:transparent;"></td>
                                       	            	
                                       	            	<td style="border:1px solid peru;font-size:12px;text-align:center;margin-left:10px; height:15px;" >
                                       	            	
                                       	            	
                                       	            	<a href="check_none.php?auid=<?php echo $row['au_id'];?>">取消关注</a>
                                       	            	
                                       	            </td>
                                       	            <td class="span1"style="background:transparent;"></td>
                                       	            
                                       	            <td style="border:1px solid peru;font-size:12px;text-align:center;margin-left:10px; height:15px;" >
                                       	            	<a href="aufiles1.php?auid=<?php echo $row['au_id'];?> ">查看文章</a>
                                       	            </td>
                                       	            <!--<td   style="border:1px solid peru;font-size:12px;text-align:center;" align="center"><a href="browseuser.php?aiid=<?php echo $row['au_id'];?>"></a> 
                                       	            	
                                       	            </td>-->
                                       	            </tr>
                                       	            <?php
                                       	            	$i++;
                                       	            }while($row=mysql_fetch_array($sql));
                                       	            }
                                       	            ?>
                                       	</tbody>
                                       	</form>
	 			
	 	</table>
	 </div>
	 <div class="span3" style="border:color:transparent; background-color:transparent;float:right;"></div>
  <div align="center" id="footer"> 版权所有  重庆师范大学计算机与信息科学学院   17计科杨丹 QQ:1390807583  </div>
</div> 
</body>
</html>