<?php
header ( "Content-type: text/html; charset=utf8" ); //设置文件编码格式
session_start();
include "Conn/conn.php";//包含连接数据库的文件
$UserName=$_POST["txt_regname"];//获取注册页面中用户名文本框中的内容
//echo $UserName;
$sql=mysql_query("select * from tb_bguser where u_name ='".$UserName."'");//在用户表中查找是否有相同的用户名
$result=mysql_fetch_array($sql);
if ($result){//找到有相同的用户名，则条件成立，输出语句
	echo "<script> alert('用户名已被注册！');history.go(-1);</script>";
	exit();
}
else{
//$_SESSION["username"]=$_POST["txt_regname"];
//@$u_id=$_SESSION["user_id"];//获取用户名的ID号
$u_name=$_POST["txt_regname"];//获取文本框中输入的用户名
$u_pwd=$_POST["txt_regpwd"];//获取密码
$u_birthday=$_POST["txt_birthday"];//获取出生日期
$u_email=$_POST["txt_regemail"];//获取邮箱

$u_QQ=$_POST["txt_qq"];
$introduction=$_POST["txt_introduction"];
	$INS=mysql_query("insert into tb_bguser (u_name,u_email,u_birthday,u_pwd,u_QQ,introduction) values ('$u_name','$u_email','$u_birthday','$u_pwd','$u_QQ','$introduction')");//注册界面中输入的所有内容插入到用户表中对应的位置
	
	    if($INS)
	    {
		    echo "<script> alert('用户注册成功！');</script>";
	        echo "<script> window.location='shouye1.php';</script>";
	    }
	    else{
		    echo "<script> alert('用户注册失败！');</script>";
		    echo "<script> window.location='register1.php';</script>";
	    }
}
?>
