<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>博客系统后台</title>
<style type="text/css">
	.container{position: relative;
			margin: 0 auto; /*整个网··页版面居中*/
			padding: 0;
			background-color: transparent;
			width: 757px;/*宽度为1000px*/
			text-align: left; /*左对齐*/
			border: 2px solid white;}
	}
	.demo{text-shadow: 0 0 5px #fff,0 0 15px #fff,0 0 25px #fff,0 0 20px #f0f,0 0 30px #f0f;} /*添加的文字效果*/
			#banner p{text-align: center; /*左右居中*/
			padding:15px 0 0 0;
			font-size: 48px; /*字体大小*/
			color: #fff;
			font-weight: bold;} /*粗字体*/
			#banner{margin:0px; /*外边距*/
			padding:0;
			margin: -50px 0 0 0;
			width: 757px; /*banner的宽度*/
			height:
			background:#e6cbfe ;}
			#footer{clear: both; /*清除左右浮动*/
			font-size: 10px;
			font-weight: bold; /*粗体字*/
			width: 100%;
			padding: 3px 0px;
			text-align: center;/*文本居中*/
			margin: 0;
			background-color: #fff;} /*背景色：白色*/
			.form1{
				border:2px solid white;background-color:papayawhip; margin-top:50px;margin-left:150px; width:400px; height:400px;border-radius:200px; background-image:url('images/timg7.gif');}
			
		body,html{
				background-color: black;
				background-image: url("images/timg8.gif");
			}
</style>
</head>
	<script src="JS/check.js" language="javascript">
</script>
<body >
	<div style="background-color:transparent;"class="container" align="center">
		<div id="banner" style="border:1px solid peachpuff;background-image:url('images/pic2.jpg'); ">
			<p class="demo" >后台管理</p>
		</div>
		<div width="757" height="500" style="height:500px;border-radius:50px; background-color:transparent;margin-bottom:40px;">
			<p align="center" style="margin-top:30px; font-size:20px;color:darkkhaki">管理员登录</p>
				<form name="form" method="post" action="check.php" align="center" class="form1" valign="center">
          <td height="20" valign="baseline" align="center">
            <table width="100%"  border="0" cellpadding="0" cellspacing="0" style="border:2px solid transparent;margin-top:90px; margin-left:-20px;">
              <tr>
                <td width="32%" height="20" align="center" valign="baseline">&nbsp; </td>
                <td width="67%" align="left" valign="baseline" style="text-indent:10px;">
                	<div >
				<ul align="center" >
				<li>用户名:
                  <input  name="txt_user" id="txt_user" size="5" width="85"><sapn style="color:red;font-size:10px;">*shzj</sapn>
                 </li>
                  <br><br>
<li>&nbsp;密&nbsp;码:
<input  name="txt_pwd" id="txt_pwd" type="password" style="FONT-SIZE: 10px; WIDTH: 65px" size="5">
	<sapn style="color:red;font-size=10px;">*123456</sapn>
</li>
	<br><br>

&nbsp;
<input style="FONT-SIZE: 9pt"  type="submit" value="登录" name="sub_dl" onClick="return f_check(form)">&nbsp;&nbsp;&nbsp;&nbsp;

<input type="reset" value="重置" class="btn_grey">
&nbsp; 
</ul>
</div>
</td>
                <td width="1%" align="center" valign="baseline">&nbsp;</td>
              </tr>
            </table> 
			</td>
		  </form>
		</div>
		
      
      
      <table  width="757" border="0" align="center" cellpadding="0" cellspacing="0">
  <div align="center" style="background-color:peachpuff;"> 版权所有  重庆师范大学计算机与信息科学学院   17计科杨丹 QQ:1390807583  </div>
  </table>
     </div>
	</body>
</html>