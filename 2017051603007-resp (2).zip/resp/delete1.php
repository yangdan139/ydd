
<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8" />
		<title></title>
	</head>
	<body>
		<?php    
			session_start();
    header ( "Content-type: text/html; charset=utf-8" ); 
	include "Conn/conn.php";//包含链接数据库的文件
	$uid=$_SESSION['uid'];
	//echo $uid;
	$id=$_GET['id'];
	//echo $id;
	$sql=mysql_query("select * from tb_bguser where user_id='".$id."'");
	$row=mysql_fetch_array($sql);
	if (!$sql)
			    {
                    printf("Error: %s\n", mysql_error());
                    exit();
            }
	$name=$row['u_name'];
	//echo $name;
	$email=$row['u_email'];
	//echo $email;
	$birthday=$row['u_birthday'];
	//echo $birthday;
	$QQ=$row['u_QQ'];
	//echo $QQ;
	$introduction=$row['introduction'];
	//echo $introduction;
	$pwd=$row['u_pwd'];
	//echo $pwd;
	$time=date("Y-m-d H:i:s"); //获取文章删除时间
	//echo $time;
	$sql1=mysql_query("insert into tb_delete1 (ad_id,d_name,d_pwd,d_email,d_birthday,d_QQ,d_introduction,d_time1) values ('$uid','$name','$pwd','$email','$birthday','$QQ','$introduction','$time')");
	$sql=mysql_query("delete from tb_comment where tb_comment.user_id='".$id."'");
	$sql2=mysql_query("delete from tb_concern where user_id='".$id."' and au_id='".$id."'");
	$sql2=mysql_query("delete from tb_articles where user_id='".$id."'");
	$sql3=mysql_query("delete from tb_bguser where user_id='".$id."'");
    if (!$sql)
			    {
                    printf("Error: %s\n", mysql_error());
                    exit();
              }
	if($sql3){
		echo "<script>alert('删除成功!');history.back();</script>";
	}
	else{	
		echo "<script>alert('删除操作失败！');history.back();</script>";
	}
	?>
	</body>
</html>
