<?php session_start();
	include "Conn/conn.php";
	$id=$_GET["auid"];
	?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link href="CSS/style.css"  rel="stylesheet">
<title>浏览关注文章</title>
<meta name="viewport" content="width=device-width,initial=scale=1.0"/>
		<link rel="stylesheet" href="../bootstrap-v2.3.2/css/bootstrap.css" />
		<link rel="stylesheet" href="../bootstrap-v2.3.2/css/bootstrap-responsive.css" />
		<script src="../bootstrap-v2.3.2/js/jquery.js"></script>
		<script src="../bootstrap-v2.3.2/js/bootstrap-dropdown.js"></script>
			<script src="../bootstrap-v2.3.2/js/bootstrap-collapse.js"></script>
		<style type="text/css">
				body{margin:10px;
				background-color:palegoldenrod;
				background-image:url('images/timg7.gif');
				}
			#footer{clear: both; /*清除左右浮动*/
			font-size: 10px;
			font-weight: bold; /*粗体字*/
			width: 100%;
			padding: 3px 0px;
			text-align: center;/*文本居中*/
			margin: 0;
			background-color: #fff;} /*背景色：白色*/
			</style>
</head>
<script src="JS/check.js"  language="javascript"></script>
<body style="margin-top: 0px; vertical-align: top; padding-top: 0px; text-align: center;background-color:palegoldenrod; "> 
	
	<?php
       if(empty($_SESSION['uid']))
        {
           echo "<script>alert('您还没有登录,请先登录!');history.back();</script>";
           exit;
        }
?>

		<div style="margin:auto; border:2px solid white;" align="center" class="container">
		<div  style=" height:149px;background-image:url('images/footer.jpg');">
			<h2 style="font-size:25px;text-align:center;padding-top:62px;">concern</h2></div>
		<div class="navbar" style="text-align:center;margin:auto;"align="center">
			<div class="navbar-inner">
				<a  class="btn btn-navbar" data-toggle="collapse" data-target=".navbar-responsive-collapse" >
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</a>
				<a href="index1.php" class="brand">博客系统</a>
				<ul class="nav nav-collapse collapse navbar-responsive-collapse">
					<li ><a href="shouye1.php"style="background-color:lightgoldenrodyellow;width:100px;margin-left:20px;border-radius:8px;"><i class="icon-home"></i>首页</a></li>
					<li class="dropdown">
						<a href="#" data-toggle="dropdown" style="background-color:lightgoldenrodyellow;width:100px;margin-left:20px;border-radius:8px;">文章管理<b class="caret"></b></a>
						<ul class="dropdown-menu">
							<li style="background-color:bisque; border-radius:4px;"><a href="file1.php">发表文章</a></li>
							<li class="divider"></li>
							<li style="background-color:bisque; border-radius:4px;"><a href="file_more1.php">所有文章</a></li>
							<li class="divider"></li>
							<li style="background-color:bisque; border-radius:4px;"><a href="myfiles1.php">我的文章</a></li>
						</ul>
					</li>
					<li class="dropdown">
						<a href="#" data-toggle="dropdown" style="background-color:lightgoldenrodyellow;width:100px;margin-left:20px;border-radius:8px;">个人中心<b class="caret"></b></a>
						<ul class="dropdown-menu">
							<li style="background-color:bisque; border-radius:4px;"><a href="browseuser1.php">个人信息</a></li>
							<li class="divider"></li>
							<li style="background-color:bisque; border-radius:4px;"><a href="myfans1.php">我的粉丝</a></li>
							<li class="divider"></li>
							<li style="background-color:bisque; border-radius:4px;"><a href="concern1.php">我的关注</a></li>
						</ul>
					</li>
					<li>
						<a href="safe2.php" style="background-color:lightgoldenrodyellow;width:100px;margin-left:20px;border-radius:8px;"><i class="icon-off"></i>退出</a></li>
				</ul>
			</div>
		</div>
		<div class="span3" style="border:color:transparent; background-color:transparent;float:left;"></div>
	  	<div class="sapn7"style="height:495px;background-image:url('images/bg.jpg');" align="center" >
	  		<h3 align="center" style="text-align:center;">
	  			关注的某一作者的文章
	  		</h3>
	  		<table  align="center" cellpadding="2" bgcolor="palegoldenrod" class="table-condensed">
	  			<thead style="font-size:12px;text-align:center;" align="center" >
	  				<th  style="border:1px solid peru;font-size:12px;text-align:center; " bgcolor="burlywood" align="center">编号</th>
	  				<th class="span1"style="background:transparent;"></th>
	  				<th style="border:1px solid peru;font-size:12px;text-align:center;" bgcolor="burlywood" align="center">文章主题</th>
	  				<th class="span1"style="background:transparent;"></th>
	  				<th style="border:1px solid peru;font-size:12px;text-align:center;" bgcolor="burlywood" align="center">发表时间</th>
	  				<th class="span1"style="background:transparent;"></th>
	  				<th style="border:1px solid peru;font-size:12px;text-align:center;" bgcolor="burlywood" align="center">取消关注</th>
	  			</thead>
	  			<tbody>
	 		<?php
                                       	$i=1;
                                       	    $sql=mysql_query("select *from tb_articles where user_id='".$id."'");
                                       	    if (!$sql)
			    {
                    printf("Error: %s\n", mysql_error());
                    exit();
                }
                                       	    $row=mysql_fetch_array($sql);
                                       	    if($row=="")
                                       	    {
                                       	?>    	<tr align="center">
                                       	           <td>还作者没有写文章哦！！！</td>
                                                </tr> 
                                       	<?php 
                                       	    }
                                       	    else{
                                       	    	do{
                                       	?>
                                       	          <tr style="border:1px solid peru;font-size:12px;text-align:center;height:18px;" align="center">
                                       	            <td style="border:1px solid peru;font-size:12px;text-align:center;" align="center" >
                                       	            	<a href="article_1.php?a_id=<?php echo $row['a_id'];?>"size="2"><?php echo $i."、";?> </a>
                                       	            	
                                       	            </td >
                                       	            <td class="span1"style="background:transparent;"></td>
                                       	            <td style="border:1px solid peru;font-size:12px;text-align:center;" align="center">
                                       	            	<a href="article_1.php?a_id=<?php echo $row['a_id'];?>"><?php echo $row['title'];?></a></td>
                                       	            	<td class="span1"style="background:transparent;"></td>
                                       	            	<td style="border:1px solid peru;font-size:12px;text-align:center;" align="center">
                                       	            	<a ><?php echo $row['time'];?></a></td>
                                       	            	<td class="span1"style="background:transparent;"></td>
                                       	            <td style="border:1px solid peru;font-size:12px;text-align:center;" align="center">
                                       	            	<a href="chceck_none.php?auid=<?php echo $row['user_id'];?>">取消关注</a></td>
                                                  </tr> 
                                       	<?php
                                       		$i++;    		
                                       	}while($row=mysql_fetch_array($sql));
                                       	    }
                                       	?> 
                                       	</tbody>
                                       	</form>
	 			
	 	</table>
	 </div>
	 <div class="span3" style="border:color:transparent; background-color:transparent;float:right;"></div>
  <div align="center" id="footer"> 版权所有  重庆师范大学计算机与信息科学学院   17计科杨丹 QQ:1390807583  </div>
</div>
</body>
</html>