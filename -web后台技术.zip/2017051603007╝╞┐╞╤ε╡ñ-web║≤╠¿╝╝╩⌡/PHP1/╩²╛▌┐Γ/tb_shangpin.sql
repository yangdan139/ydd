/*
Navicat MySQL Data Transfer

Source Server         : 大宇服务器
Source Server Version : 50611
Source Host           : dev.dxdc.net:3306
Source Database       : a0925234204

Target Server Type    : MYSQL
Target Server Version : 50611
File Encoding         : 65001

Date: 2019-01-09 13:15:33
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `tb_shangpin`
-- ----------------------------
DROP TABLE IF EXISTS `tb_shangpin`;
CREATE TABLE `tb_shangpin` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `mingcheng` varchar(25) DEFAULT NULL,
  `jianjie` mediumtext,
  `addtime` varchar(25) DEFAULT NULL,
  `dengji` varchar(5) DEFAULT NULL,
  `xinghao` varchar(25) DEFAULT NULL,
  `tupian` varchar(200) DEFAULT NULL,
  `shuliang` int(4) DEFAULT NULL,
  `cishu` int(4) DEFAULT NULL,
  `tuijian` int(4) DEFAULT NULL,
  `typeid` int(4) DEFAULT NULL,
  `huiyuanjia` varchar(25) DEFAULT NULL,
  `shichangjia` varchar(25) DEFAULT NULL,
  `pinpai` varchar(25) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=218 DEFAULT CHARSET=gb2312;

-- ----------------------------
-- Records of tb_shangpin
-- ----------------------------
INSERT INTO `tb_shangpin` VALUES ('211', '数码相机', '引领时尚的数码科技', '2006-5-5', '精品', 'XM-5001', 'admin/upimages/5.jpg', '20000', '10', '1', '3', '2599', '2699', '时尚');
INSERT INTO `tb_shangpin` VALUES ('202', '水杯', '无', '1995-1-1', '精品', '44', 'admin/upimages/1.jpg', '1800', '22', '1', '8', '98', '100', '44');
INSERT INTO `tb_shangpin` VALUES ('203', '全自动洗衣机', '无', '2005-7-8', '一般', '301X', 'admin/upimages/4.jpg', '8000', '0', '1', '8', '1699', '1800', 'X44');
INSERT INTO `tb_shangpin` VALUES ('212', '玩具车', '好车，very good', '2002-2-1', '精品', 'Handle-88', 'admin/upimages/3.jpg', '888', '0', '0', '12', '366', '399', 'LOVE-88');
INSERT INTO `tb_shangpin` VALUES ('213', '家庭影院', '质、精', '2007-1-1', '精品', 'LOVE-99', 'admin/upimages/7.jpg', '98', '1', '1', '3', '9599', '9999', '时尚LOVE');
INSERT INTO `tb_shangpin` VALUES ('214', '液晶显示器', '经济实用', '2006-1-1', '精品', 'LOVE-999', 'admin/upimages/77.jpg', '99', '0', '1', '3', '2666', '2999', '时尚LOVE');
INSERT INTO `tb_shangpin` VALUES ('215', '液晶显示器LVOE', '优惠', '2007-1-1', '一般', 'LOVE-2', 'admin/upimages/2.jpg', '88', '0', '0', '3', '1399', '1499', 'LOVE2');
INSERT INTO `tb_shangpin` VALUES ('216', 'aaaa', '免检产品', '2007-1-1', '一般', 'a', 'admin/upimages/9.jpg', '0', '10', '1', '22', '800', '1000', 'a');
