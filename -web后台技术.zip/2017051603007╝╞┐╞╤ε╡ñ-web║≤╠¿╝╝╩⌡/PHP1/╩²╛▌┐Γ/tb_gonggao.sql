/*
Navicat MySQL Data Transfer

Source Server         : 大宇服务器
Source Server Version : 50611
Source Host           : dev.dxdc.net:3306
Source Database       : a0925234204

Target Server Type    : MYSQL
Target Server Version : 50611
File Encoding         : 65001

Date: 2019-01-09 13:04:50
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `tb_gonggao`
-- ----------------------------
DROP TABLE IF EXISTS `tb_gonggao`;
CREATE TABLE `tb_gonggao` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `title` varchar(66) DEFAULT NULL,
  `content` text,
  `time` varchar(16) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=26 DEFAULT CHARSET=gb2312;

-- ----------------------------
-- Records of tb_gonggao
-- ----------------------------
INSERT INTO `tb_gonggao` VALUES ('25', '', '', '2018-12-15');
INSERT INTO `tb_gonggao` VALUES ('23', '等等', '大大的', '2010-08-16');
INSERT INTO `tb_gonggao` VALUES ('24', '大大的', '大大的', '2010-08-16');
