/*
Navicat MySQL Data Transfer

Source Server         : 大宇服务器
Source Server Version : 50611
Source Host           : dev.dxdc.net:3306
Source Database       : a0925234204

Target Server Type    : MYSQL
Target Server Version : 50611
File Encoding         : 65001

Date: 2019-01-09 13:04:35
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `tb_dingdan`
-- ----------------------------
DROP TABLE IF EXISTS `tb_dingdan`;
CREATE TABLE `tb_dingdan` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `dingdanhao` varchar(125) DEFAULT NULL,
  `spc` varchar(125) DEFAULT NULL,
  `slc` varchar(125) DEFAULT NULL,
  `shouhuoren` varchar(25) DEFAULT NULL,
  `sex` varchar(2) DEFAULT NULL,
  `dizhi` varchar(125) DEFAULT NULL,
  `youbian` varchar(10) DEFAULT NULL,
  `tel` varchar(25) DEFAULT NULL,
  `email` varchar(25) DEFAULT NULL,
  `shff` varchar(25) DEFAULT NULL,
  `zfff` varchar(25) DEFAULT NULL,
  `leaveword` mediumtext,
  `time` varchar(25) DEFAULT NULL,
  `xiadanren` varchar(25) DEFAULT NULL,
  `zt` varchar(50) DEFAULT NULL,
  `total` varchar(25) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=105 DEFAULT CHARSET=gb2312;

-- ----------------------------
-- Records of tb_dingdan
-- ----------------------------
INSERT INTO `tb_dingdan` VALUES ('79', '2007111415234939', '211@', '1@', 'dd', '男', 'dd', '130031', '0431-84978***', 'aa@sina.com', '送货上门', '建设银行汇款', 'ddd', '2007-11-14 15:23:49', '纯净水', '已发货&nbsp;', '2599');
INSERT INTO `tb_dingdan` VALUES ('99', '2007112911451739', '213@', '1@', '纯净水', '女', '黑龙江', '130021', '136********', '130021', '普通平邮', '建设银行汇款', '无', '2007-11-29 11:45:17', '纯净水', '未作任何处理', '9599');
INSERT INTO `tb_dingdan` VALUES ('98', '2007112911423439', '215@', '1@', '纯净水', '女', '长春市', '130021', '136********', 'tiansi***@sina.com', '普通平邮', '建设银行汇款', '无', '2007-11-29 11:42:34', '纯净水', '未作任何处理', '1399');
INSERT INTO `tb_dingdan` VALUES ('80', '2007111415332239', '202@', '6@', 'ss', '男', 'ss', '130000', '0431-8497226*', '454@ekek.com', '特快专递', '建设银行汇款', 'ddd', '2007-11-14 15:33:22', '纯净水', '已发货&nbsp;', '588');
INSERT INTO `tb_dingdan` VALUES ('78', '2007111415170839', '211@202@', '2@1@', '深奥', '男', '长春', '130000', '1365698***', 'chunjingshui**@si*.com', '特快专递', '建设银行汇款', '正在测试中', '2007-11-14 15:17:08', '纯净水', '已发货&nbsp;', '5296');
INSERT INTO `tb_dingdan` VALUES ('81', '2007111415360839', '202@', '4@', 'll', '男', 'dd', '130000', '0431-8497226*', '454@ekek.com', '普通平邮', '建设银行汇款', 'ddd', '2007-11-14 15:36:08', '纯净水', '已发货&nbsp;', '392');
INSERT INTO `tb_dingdan` VALUES ('82', '2007111415421739', '202@', '8@', 'dddd', '男', 'dddd', '3333333', '33333', '454@ekek.com', '普通平邮', '建设银行汇款', '333', '2007-11-14 15:42:17', '纯净水', '已发货&nbsp;', '784');
INSERT INTO `tb_dingdan` VALUES ('83', '2007111415531039', '202@', '1@', 'ddddd', '男', 'dddd', '130000', '0431-8497226*', 'aa@sina.com', '特快专递', '建设银行汇款', 'dfdf', '2007-11-14 15:53:10', '纯净水', '未作任何处理', '98');
INSERT INTO `tb_dingdan` VALUES ('84', '2007111508514439', '202@', '2@', 'ldsf', '男', 'laksf', 'lksf', 'lk21', 'fjlkd@sina.com', '普通平邮', '建设银行汇款', 'sdf', '2007-11-15 08:51:44', '纯净水', '已收款&nbsp;已发货&nbsp;已收货&nbsp;', '196');
INSERT INTO `tb_dingdan` VALUES ('85', '2007111915194439', '211@', '2@', 'sss', '男', 'sss', 'ss', 'ssss', '454@ekek.com', '普通平邮', '建设银行汇款', 'dfdf', '2007-11-19 15:19:44', '纯净水', '未作任何处理', '5198');
INSERT INTO `tb_dingdan` VALUES ('87', '2007112118305339', '211@', '2@', 'sdfdf', '男', 'fsdff', 'sdfsdf', 'sfsfsdfs', '454@ekek.com', '普通平邮', '建设银行汇款', 'dfsdf', '2007-11-21 18:30:53', '纯净水', '已收款&nbsp;已发货&nbsp;已收货&nbsp;', '5198');
INSERT INTO `tb_dingdan` VALUES ('88', '2007112214363739', '211@', '1@', '紫璇', '女', '吉林省长春市河东路1**号', '130000', '0431-84978***', 'zixuan**@si*.com', '送货上门', '网上支付', '保证质量，轻拿轻放！货到前10分钟打电话通知！', '2007-11-22 14:36:37', '纯净水', '未作任何处理', '2599');
INSERT INTO `tb_dingdan` VALUES ('97', '2007112911284639', '216@@', '10@@', '纯净水', '女', '长春市', '130021', '136********', 'tiansi***@sina.com', '普通平邮', '建设银行汇款', '急', '2007-11-29 11:28:46', '纯净水', '已收款&nbsp;已发货&nbsp;已收货&nbsp;', '8000');
INSERT INTO `tb_dingdan` VALUES ('90', '2007112215175939', '211@', '1@', 'ddddd', '女', 'dddd', 'ddd', 'ddd', 'dd@aa.com', '普通平邮', '建设银行汇款', 'ddfsdf', '2007-11-22 15:17:59', '纯净水', '未作任何处理', '2599');
INSERT INTO `tb_dingdan` VALUES ('91', '2007112215263939', '211@', '1@', '33', '男', '4435', '332', '22', '454@ekek.com', '普通平邮', '建设银行汇款', 'asdf', '2007-11-22 15:26:39', '纯净水', '未作任何处理', '2599');
INSERT INTO `tb_dingdan` VALUES ('100', '2007112913155042', '213@', '1@', 'lx', '男', '1', '1300211', '10', '12.@lkfj.com', '普通平邮', '建设银行汇款', '1', '2007-11-29 13:15:50', 'lx', '已收款&nbsp;已发货&nbsp;已收货&nbsp;', '9599');
INSERT INTO `tb_dingdan` VALUES ('95', '2007112813551939', '213@', '1@', 'dfer', '男', 'dfer', 'ererwer', 'rrwerwer', 'rwer**@dins.com', '送货上门', '建设银行汇款', 'ewrwer', '2007-11-28 13:55:19', '纯净水', '未作任何处理', '9599');
INSERT INTO `tb_dingdan` VALUES ('96', '2007112814155139', '213@', '1@', 'retret', '男', 'dfder', 'erwr', '435', '454***@ekek.com', '送货上门', '建设银行汇款', 'dfr34', '2007-11-28 14:15:51', '纯净水', '未作任何处理', '9599');
INSERT INTO `tb_dingdan` VALUES ('101', '2007113010324643', '213@', '1@', '张丽', '女', '长春市', '130021', '136********', 'tiansi***@sina.com', '普通平邮', '建设银行汇款', '无', '2007-11-30 10:32:46', 'lx', '未作任何处理', '9599');
INSERT INTO `tb_dingdan` VALUES ('102', '20181215143452', '', '', '', '', '', '', '', '', '', '', '', '2018-12-15 14:34:52', '', '未作任何处理', '');
INSERT INTO `tb_dingdan` VALUES ('103', '20181215143517', '', '', '', '', '', '', '', '', '', '', '', '2018-12-15 14:35:17', '', '未作任何处理', '');
INSERT INTO `tb_dingdan` VALUES ('104', '20181215144100', '', '', '', '', '', '', '', '', '', '', '', '2018-12-15 14:41:00', '', '未作任何处理', '');
