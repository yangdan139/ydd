/*
Navicat MySQL Data Transfer

Source Server         : 大宇服务器
Source Server Version : 50611
Source Host           : dev.dxdc.net:3306
Source Database       : a0925234204

Target Server Type    : MYSQL
Target Server Version : 50611
File Encoding         : 65001

Date: 2019-01-09 13:14:45
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `tb_links`
-- ----------------------------
DROP TABLE IF EXISTS `tb_links`;
CREATE TABLE `tb_links` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `linkname` varchar(50) NOT NULL,
  `linkurl` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=gb2312;

-- ----------------------------
-- Records of tb_links
-- ----------------------------
INSERT INTO `tb_links` VALUES ('1', '编程体验网', 'http://www.bcty365.com');
INSERT INTO `tb_links` VALUES ('2', '编程资源网', 'http://www.bc110.com');
INSERT INTO `tb_links` VALUES ('3', '编程词典网', 'http://www.mrbccd.com');
INSERT INTO `tb_links` VALUES ('4', '编程词典网', 'http://www.mrbccd.net');
INSERT INTO `tb_links` VALUES ('5', '编程体验网', 'http://www.cccxy.com');
INSERT INTO `tb_links` VALUES ('6', '编程词典网', 'http://www.mrbccd.cn');
