/*
Navicat MySQL Data Transfer

Source Server         : 大宇服务器
Source Server Version : 50611
Source Host           : dev.dxdc.net:3306
Source Database       : a0925234204

Target Server Type    : MYSQL
Target Server Version : 50611
File Encoding         : 65001

Date: 2019-01-09 13:16:02
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `tb_users`
-- ----------------------------
DROP TABLE IF EXISTS `tb_users`;
CREATE TABLE `tb_users` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `name` varchar(25) DEFAULT NULL,
  `pwd` varchar(50) DEFAULT NULL,
  `dongjie` int(4) DEFAULT NULL,
  `email` varchar(25) DEFAULT NULL,
  `sfzh` varchar(25) DEFAULT NULL,
  `tel` varchar(25) DEFAULT NULL,
  `qq` varchar(25) DEFAULT NULL,
  `tishi` varchar(50) DEFAULT NULL,
  `huida` varchar(50) DEFAULT NULL,
  `dizhi` varchar(100) DEFAULT NULL,
  `youbian` varchar(25) DEFAULT NULL,
  `regtime` varchar(25) DEFAULT NULL,
  `truename` varchar(25) DEFAULT NULL,
  `pwd1` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=46 DEFAULT CHARSET=gb2312;

-- ----------------------------
-- Records of tb_users
-- ----------------------------
INSERT INTO `tb_users` VALUES ('41', '深蓝易思', '96e79218965eb72c92a549dd5a330112', '0', '', '', '', '', '您最喜欢的花', '百合花', '', '', '2007-11-14', '', '111111');
INSERT INTO `tb_users` VALUES ('44', 'mr', 'fdb390e945559e74475ed8c8bbb48ca5', '0', '', '', '', '', '你的爱好', '大大的', '', '', '2010-08-16', '', 'mrsoft');
INSERT INTO `tb_users` VALUES ('39', '纯净水', 'fdb390e945559e74475ed8c8bbb48ca5', '0', '', '', '', '', '您最喜欢的花', '百合花', '', '', '2007-10-26', '', 'mrsoft');
INSERT INTO `tb_users` VALUES ('43', 'lx', '96e79218965eb72c92a549dd5a330112', '0', '', '', '', '', '您的生日', '不告诉你', '', '', '2007-11-29', '', '111111');
INSERT INTO `tb_users` VALUES ('45', 'yd', 'e10adc3949ba59abbe56e057f20f883e', '0', '', '', '', '', '你的爱好', '花', '', '', '2018-12-15', '', '123456');
