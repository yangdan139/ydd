/*
Navicat MySQL Data Transfer

Source Server         : 大宇服务器
Source Server Version : 50611
Source Host           : dev.dxdc.net:3306
Source Database       : a0925234204

Target Server Type    : MYSQL
Target Server Version : 50611
File Encoding         : 65001

Date: 2019-01-09 13:14:18
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `tb_leavewords`
-- ----------------------------
DROP TABLE IF EXISTS `tb_leavewords`;
CREATE TABLE `tb_leavewords` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `userid` int(4) DEFAULT NULL,
  `title` varchar(66) DEFAULT NULL,
  `content` text,
  `time` varchar(16) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=gb2312;

-- ----------------------------
-- Records of tb_leavewords
-- ----------------------------
INSERT INTO `tb_leavewords` VALUES ('12', '38', '????', '???????????????????', '2007-01-15');
INSERT INTO `tb_leavewords` VALUES ('15', '0', '', '', '2018-12-15');
INSERT INTO `tb_leavewords` VALUES ('16', '0', '', '', '2018-12-15');
