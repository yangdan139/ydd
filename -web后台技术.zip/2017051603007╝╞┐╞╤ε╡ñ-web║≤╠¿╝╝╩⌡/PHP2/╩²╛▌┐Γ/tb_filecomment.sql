/*
Navicat MySQL Data Transfer

Source Server         : 大宇服务器
Source Server Version : 50611
Source Host           : dev.dxdc.net:3306
Source Database       : a0925234204

Target Server Type    : MYSQL
Target Server Version : 50611
File Encoding         : 65001

Date: 2019-01-09 14:29:34
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `tb_filecomment`
-- ----------------------------
DROP TABLE IF EXISTS `tb_filecomment`;
CREATE TABLE `tb_filecomment` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `a_id` int(4) NOT NULL DEFAULT '0',
  `filecontent` text NOT NULL,
  `datetime` datetime DEFAULT '0000-00-00 00:00:00',
  `u_id` int(4) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=68 DEFAULT CHARSET=gb2312 ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of tb_filecomment
-- ----------------------------
INSERT INTO `tb_filecomment` VALUES ('66', '0', '1', '2019-01-08 12:08:40', '0');
INSERT INTO `tb_filecomment` VALUES ('67', '0', '1', '2019-01-08 12:09:10', '0');
