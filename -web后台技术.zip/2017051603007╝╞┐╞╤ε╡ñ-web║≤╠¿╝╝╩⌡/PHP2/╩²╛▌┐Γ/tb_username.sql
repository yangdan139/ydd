/*
Navicat MySQL Data Transfer

Source Server         : 大宇服务器
Source Server Version : 50611
Source Host           : dev.dxdc.net:3306
Source Database       : a0925234204

Target Server Type    : MYSQL
Target Server Version : 50611
File Encoding         : 65001

Date: 2019-01-09 14:29:47
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `tb_username`
-- ----------------------------
DROP TABLE IF EXISTS `tb_username`;
CREATE TABLE `tb_username` (
  `u_id` int(20) NOT NULL AUTO_INCREMENT,
  `regname` varchar(20) NOT NULL,
  `regrealname` varchar(20) NOT NULL,
  `regpwd` varchar(40) NOT NULL,
  `regbirthday` date NOT NULL DEFAULT '0000-00-00',
  `regemail` varchar(100) NOT NULL,
  `fig` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`u_id`)
) ENGINE=MyISAM AUTO_INCREMENT=24 DEFAULT CHARSET=gb2312 ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of tb_username
-- ----------------------------
INSERT INTO `tb_username` VALUES ('1', 'yd', 'yd', '111', '2019-01-08', '183@qq.com', '1');
