/*
Navicat MySQL Data Transfer

Source Server         : 大宇服务器
Source Server Version : 50611
Source Host           : dev.dxdc.net:3306
Source Database       : a0925234204

Target Server Type    : MYSQL
Target Server Version : 50611
File Encoding         : 65001

Date: 2019-01-09 13:31:46
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `tb_affiche`
-- ----------------------------
DROP TABLE IF EXISTS `tb_affiche`;
CREATE TABLE `tb_affiche` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `title` varchar(200) CHARACTER SET gb2312 NOT NULL,
  `content` mediumtext CHARACTER SET gb2312 NOT NULL,
  `createtime` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=39 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of tb_affiche
-- ----------------------------
INSERT INTO `tb_affiche` VALUES ('25', '《PHP项目开发全程实录》即将出版啦！', '广大的读者朋友您好，《PHP项目开发全程实录》08年4月中旬即将出版发行！敬请关注！', '2008-04-02 09:37:43');
INSERT INTO `tb_affiche` VALUES ('2', 'Happy Every Day!', 'Every day ! in Every Day! I am getting better and better!', '2008-04-02 15:41:45');
INSERT INTO `tb_affiche` VALUES ('38', '可不可以', '可不可以', '2018-12-01 18:56:13');
